import 'package:nylon/features/home/data/models/mobile_featured.dart';

class OneOrderModel {
  DataOrder? data;

  OneOrderModel({this.data});

  OneOrderModel.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? new DataOrder.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }

  List<String> getProductNames(List<Products> productList) {
    return productList.map((product) => product.name ?? '').toList();
  }

  List<String> getProductModel(List<Products> productList) {
    return productList.map((product) => product.model ?? '').toList();
  }
}

class History {
  String? dateAdded;
  String? status;
  String? comment;

  History({this.dateAdded, this.status, this.comment});

  History.fromJson(Map<String, dynamic> json) {
    dateAdded = json['date_added'];
    status = json['status'];
    comment = json['comment'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['date_added'] = this.dateAdded;
    data['status'] = this.status;
    data['comment'] = this.comment;
    return data;
  }
}

class DataOrder {
  List<History>? histories;

  String? orderId;
  String? invoiceNo;
  String? invoicePrefix;
  String? storeId;
  String? storeName;
  String? storeUrl;
  String? customerId;
  String? customer;
  String? customerGroupId;
  String? firstname;
  String? lastname;
  String? email;
  String? telephone;
  String? orderShippingId;
  dynamic customField;
  String? paymentFirstname;
  String? paymentLastname;
  String? paymentCompany;
  String? paymentAddress1;
  String? paymentAddress2;
  String? paymentPostcode;
  String? paymentCity;
  String? paymentZoneId;
  String? paymentZone;
  String? paymentZoneCode;
  String? paymentCountryId;
  String? paymentCountry;
  String? paymentIsoCode2;
  String? paymentIsoCode3;
  String? paymentAddressFormat;
  List<Null>? paymentCustomField;
  String? paymentMethod;
  String? paymentCode;
  String? shippingFirstname;
  String? shippingLastname;
  String? shippingCompany;
  String? shippingAddress1;
  String? shippingAddress2;
  String? shippingPostcode;
  String? shippingCity;
  String? shippingZoneId;
  String? shippingZone;
  String? shippingZoneCode;
  String? shippingCountryId;
  String? shippingCountry;
  String? shippingIsoCode2;
  String? shippingIsoCode3;
  String? shippingAddressFormat;
  List<Null>? shippingCustomField;
  dynamic shippingMethod;
  String? shippingCode;
  String? comment;
  String? image;
  String? total;
  int? reward;
  String? orderStatusId;
  dynamic orderStatus;
  String? affiliateId;
  String? affiliateFirstname;
  String? affiliateLastname;
  String? commission;
  String? languageId;
  String? languageCode;
  String? currencyId;
  String? currencyCode;
  String? currencyValue;
  String? ip;
  String? forwardedIp;
  String? userAgent;
  String? acceptLanguage;
  String? dateAdded;
  String? dateModified;
  String? configTabbyCapture;
  List<CustomerData>? customerData;
  String? customerGroup;
  List<Products>? products;
  List<TotalData>? totalData;

  DataOrder(
      {this.orderId,
      this.invoiceNo,
      this.invoicePrefix,
      this.storeId,
      this.storeName,
      this.storeUrl,
      this.customerId,
      this.customer,
      this.customerGroupId,
      this.firstname,
      this.lastname,
      this.email,
      this.telephone,
      this.orderShippingId,
      this.customField,
      this.paymentFirstname,
      this.paymentLastname,
      this.paymentCompany,
      this.paymentAddress1,
      this.paymentAddress2,
      this.paymentPostcode,
      this.paymentCity,
      this.paymentZoneId,
      this.paymentZone,
      this.paymentZoneCode,
      this.paymentCountryId,
      this.paymentCountry,
      this.paymentIsoCode2,
      this.paymentIsoCode3,
      this.paymentAddressFormat,
      this.paymentCustomField,
      this.paymentMethod,
      this.paymentCode,
      this.shippingFirstname,
      this.shippingLastname,
      this.shippingCompany,
      this.shippingAddress1,
      this.shippingAddress2,
      this.shippingPostcode,
      this.shippingCity,
      this.shippingZoneId,
      this.shippingZone,
      this.shippingZoneCode,
      this.shippingCountryId,
      this.shippingCountry,
      this.shippingIsoCode2,
      this.shippingIsoCode3,
      this.shippingAddressFormat,
      this.shippingCustomField,
      this.shippingMethod,
      this.shippingCode,
      this.comment,
      this.image,
      this.total,
      this.reward,
      this.orderStatusId,
      this.orderStatus,
      this.affiliateId,
      this.affiliateFirstname,
      this.affiliateLastname,
      this.commission,
      this.languageId,
      this.languageCode,
      this.currencyId,
      this.currencyCode,
      this.currencyValue,
      this.ip,
      this.forwardedIp,
      this.userAgent,
      this.acceptLanguage,
      this.dateAdded,
      this.dateModified,
      this.configTabbyCapture,
      this.customerData,
      this.customerGroup,
      this.products,
      this.totalData});

  DataOrder.fromJson(Map<String, dynamic> json) {
    orderId = json['order_id'];
    invoiceNo = json['invoice_no'];
    invoicePrefix = json['invoice_prefix'];
    storeId = json['store_id'];
    storeName = json['store_name'];
    storeUrl = json['store_url'];
    customerId = json['customer_id'];
    customer = json['customer'];
    customerGroupId = json['customer_group_id'];
    firstname = json['firstname'];
    lastname = json['lastname'];
    email = json['email'];
    telephone = json['telephone'];
    orderShippingId = json['order_shipping_id'];
    customField = json['custom_field'];
    paymentFirstname = json['payment_firstname'];
    paymentLastname = json['payment_lastname'];
    paymentCompany = json['payment_company'];
    paymentAddress1 = json['payment_address_1'];
    paymentAddress2 = json['payment_address_2'];
    paymentPostcode = json['payment_postcode'];
    paymentCity = json['payment_city'];
    paymentZoneId = json['payment_zone_id'];
    paymentZone = json['payment_zone'];
    paymentZoneCode = json['payment_zone_code'];
    paymentCountryId = json['payment_country_id'];
    paymentCountry = json['payment_country'];
    paymentIsoCode2 = json['payment_iso_code_2'];
    paymentIsoCode3 = json['payment_iso_code_3'];
    paymentAddressFormat = json['payment_address_format'];

    paymentMethod = json['payment_method'];
    paymentCode = json['payment_code'];
    shippingFirstname = json['shipping_firstname'];
    shippingLastname = json['shipping_lastname'];
    shippingCompany = json['shipping_company'];
    shippingAddress1 = json['shipping_address_1'];
    shippingAddress2 = json['shipping_address_2'];
    shippingPostcode = json['shipping_postcode'];
    shippingCity = json['shipping_city'];
    shippingZoneId = json['shipping_zone_id'];
    shippingZone = json['shipping_zone'];
    shippingZoneCode = json['shipping_zone_code'];
    shippingCountryId = json['shipping_country_id'];
    shippingCountry = json['shipping_country'];
    shippingIsoCode2 = json['shipping_iso_code_2'];
    shippingIsoCode3 = json['shipping_iso_code_3'];
    shippingAddressFormat = json['shipping_address_format'];

    shippingMethod = json['shipping_method'];
    shippingCode = json['shipping_code'];
    comment = json['comment'];
    image = json['image'];
    total = json['total'];
    reward = json['reward'];
    orderStatusId = json['order_status_id'];
    orderStatus = json['order_status'];
    affiliateId = json['affiliate_id'];
    affiliateFirstname = json['affiliate_firstname'];
    affiliateLastname = json['affiliate_lastname'];
    commission = json['commission'];
    languageId = json['language_id'];
    languageCode = json['language_code'];
    currencyId = json['currency_id'];
    currencyCode = json['currency_code'];
    currencyValue = json['currency_value'];
    ip = json['ip'];
    forwardedIp = json['forwarded_ip'];
    userAgent = json['user_agent'];
    acceptLanguage = json['accept_language'];
    dateAdded = json['date_added'];
    dateModified = json['date_modified'];
    configTabbyCapture = json['config_tabby_capture'];
    // if (json['customer_data'] != null) {
    //   customerData = <CustomerData>[];
    //   json['customer_data'].forEach((v) {
    //     customerData!.add(new CustomerData.fromJson(v));
    //   });
    // }
    if (json['histories'] != null) {
      histories = <History>[];
      json['histories'].forEach((v) {
        histories!.add(History.fromJson(v));
      });
    }

    customerGroup = json['customer_group'];
    if (json['products'] != null) {
      products = <Products>[];
      json['products'].forEach((v) {
        products!.add(new Products.fromJson(v));
      });
    }
    if (json['total_data'] != null) {
      totalData = <TotalData>[];
      json['total_data'].forEach((v) {
        totalData!.add(new TotalData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['order_id'] = this.orderId;
    data['invoice_no'] = this.invoiceNo;
    data['invoice_prefix'] = this.invoicePrefix;
    data['store_id'] = this.storeId;
    data['store_name'] = this.storeName;
    data['store_url'] = this.storeUrl;
    data['customer_id'] = this.customerId;
    data['customer'] = this.customer;
    data['customer_group_id'] = this.customerGroupId;
    data['firstname'] = this.firstname;
    data['lastname'] = this.lastname;
    data['email'] = this.email;
    data['telephone'] = this.telephone;
    data['order_shipping_id'] = this.orderShippingId;
    data['custom_field'] = this.customField;
    data['payment_firstname'] = this.paymentFirstname;
    data['payment_lastname'] = this.paymentLastname;
    data['payment_company'] = this.paymentCompany;
    data['payment_address_1'] = this.paymentAddress1;
    data['payment_address_2'] = this.paymentAddress2;
    data['payment_postcode'] = this.paymentPostcode;
    data['payment_city'] = this.paymentCity;
    data['payment_zone_id'] = this.paymentZoneId;
    data['payment_zone'] = this.paymentZone;
    data['payment_zone_code'] = this.paymentZoneCode;
    data['payment_country_id'] = this.paymentCountryId;
    data['payment_country'] = this.paymentCountry;
    data['payment_iso_code_2'] = this.paymentIsoCode2;
    data['payment_iso_code_3'] = this.paymentIsoCode3;
    data['payment_address_format'] = this.paymentAddressFormat;

    data['payment_method'] = this.paymentMethod;
    data['payment_code'] = this.paymentCode;
    data['shipping_firstname'] = this.shippingFirstname;
    data['shipping_lastname'] = this.shippingLastname;
    data['shipping_company'] = this.shippingCompany;
    data['shipping_address_1'] = this.shippingAddress1;
    data['shipping_address_2'] = this.shippingAddress2;
    data['shipping_postcode'] = this.shippingPostcode;
    data['shipping_city'] = this.shippingCity;
    data['shipping_zone_id'] = this.shippingZoneId;
    data['shipping_zone'] = this.shippingZone;
    data['shipping_zone_code'] = this.shippingZoneCode;
    data['shipping_country_id'] = this.shippingCountryId;
    data['shipping_country'] = this.shippingCountry;
    data['shipping_iso_code_2'] = this.shippingIsoCode2;
    data['shipping_iso_code_3'] = this.shippingIsoCode3;
    data['shipping_address_format'] = this.shippingAddressFormat;

    data['shipping_method'] = this.shippingMethod;
    data['shipping_code'] = this.shippingCode;
    data['comment'] = this.comment;
    data['image'] = this.image;
    data['total'] = this.total;
    data['reward'] = this.reward;
    data['order_status_id'] = this.orderStatusId;
    data['order_status'] = this.orderStatus;
    data['affiliate_id'] = this.affiliateId;
    data['affiliate_firstname'] = this.affiliateFirstname;
    data['affiliate_lastname'] = this.affiliateLastname;
    data['commission'] = this.commission;
    data['language_id'] = this.languageId;
    data['language_code'] = this.languageCode;
    data['currency_id'] = this.currencyId;
    data['currency_code'] = this.currencyCode;
    data['currency_value'] = this.currencyValue;
    data['ip'] = this.ip;
    data['forwarded_ip'] = this.forwardedIp;
    data['user_agent'] = this.userAgent;
    data['accept_language'] = this.acceptLanguage;
    data['date_added'] = this.dateAdded;
    data['date_modified'] = this.dateModified;
    data['config_tabby_capture'] = this.configTabbyCapture;
    if (this.customerData != null) {
      data['customer_data'] =
          this.customerData!.map((v) => v.toJson()).toList();
    }
    if (this.histories != null) {
      data['histories'] = this.histories!.map((v) => v.toJson()).toList();
    }
    data['customer_group'] = this.customerGroup;
    if (this.products != null) {
      data['products'] = this.products!.map((v) => v.toJson()).toList();
    }
    if (this.totalData != null) {
      data['total_data'] = this.totalData!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class CustomerData {
  String? customerGroupId;
  String? approval;
  String? sortOrder;
  String? languageId;
  String? name;
  String? description;

  CustomerData(
      {this.customerGroupId,
      this.approval,
      this.sortOrder,
      this.languageId,
      this.name,
      this.description});

  CustomerData.fromJson(Map<String, dynamic> json) {
    customerGroupId = json['customer_group_id'];
    approval = json['approval'];
    sortOrder = json['sort_order'];
    languageId = json['language_id'];
    name = json['name'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['customer_group_id'] = this.customerGroupId;
    data['approval'] = this.approval;
    data['sort_order'] = this.sortOrder;
    data['language_id'] = this.languageId;
    data['name'] = this.name;
    data['description'] = this.description;
    return data;
  }
}

class Products extends Productss {
  String? orderProductId;
  String? productIdP;
  String? nameP;
  String? imageP;
  String? model;
  List<Null>? option;
  dynamic quantity;
  dynamic productPrice;
  dynamic totalOrderWithoutTax;

  Products({
    this.orderProductId,
    this.productIdP,
    this.nameP,
    this.imageP,
    this.model,
    this.option,
    this.quantity,
    this.productPrice,
    this.totalOrderWithoutTax,
    required super.name,
    required super.productId,
    required super.price,
    required super.description,
    required super.image,
    required productIP,
  });

  factory Products.fromJson(Map<String, dynamic> json) {
    return Products(
      name: json['name'],
      productId: json['product_id'],
      price: json['product_price'],
      description: json['model'],
      image: json['image'],
      productIP: json['product_id'],
      orderProductId: json['order_product_id'],
      productIdP: json['product_id'],
      nameP: json['name'],
      imageP: json['image'],
      model: json['model'],
      quantity: json['quantity'],
      productPrice: json['product_price'],
      totalOrderWithoutTax: json['total_order_without_tax'],
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['order_product_id'] = this.orderProductId;
    data['product_id'] = this.productId;
    data['name'] = this.name;
    data['image'] = this.image;
    data['model'] = this.model;

    data['quantity'] = this.quantity;
    data['product_price'] = this.productPrice;
    data['total_order_without_tax'] = this.totalOrderWithoutTax;
    return data;
  }
}

class TotalData {
  String? title;
  dynamic text;

  TotalData({this.title, this.text});

  TotalData.fromJson(Map<String, dynamic> json) {
    title = json['title'];
    text = json['text'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['title'] = this.title;
    data['text'] = this.text;
    return data;
  }
}
