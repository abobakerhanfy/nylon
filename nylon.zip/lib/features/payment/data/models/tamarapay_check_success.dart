class TamarapayCheckOrdersuccess {
  bool? success;
  String? message;
  String? orderId;

  TamarapayCheckOrdersuccess({this.success, this.message, this.orderId});

  TamarapayCheckOrdersuccess.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    message = json['message'];
    orderId = json['order_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    data['message'] = this.message;
    data['order_id'] = this.orderId;
    return data;
  }
}


class TamarapayCheckOrdErerror {
  bool? success;
  String? error;

  TamarapayCheckOrdErerror({this.success, this.error});

  TamarapayCheckOrdErerror.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    error = json['error'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    data['error'] = this.error;
    return data;
  }
}