import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nylon/core/function/hindling_data_view.dart';
import 'package:nylon/core/function/status_request.dart';
import 'package:nylon/core/theme/colors_app.dart';
import 'package:nylon/features/cart/presentation/screens/widgets/container_cart_product.dart';
import 'package:nylon/features/cart/presentation/screens/widgets/button_on_cart.dart';
import 'package:nylon/features/cart/presentation/controller/controller_cart.dart';
import 'package:nylon/features/cart/presentation/screens/widgets/field_cart.dart';
import 'package:nylon/features/coupon/presentation/controller/controller_coupon.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';

// ignore: must_be_immutable
class Cart extends StatefulWidget {
  Cart({super.key});

  @override
  State<Cart> createState() => _CartState();
}

class StaggeredSlideIn extends StatelessWidget {
  final int index;
  final Widget child;

  const StaggeredSlideIn({required this.index, required this.child});

  @override
  Widget build(BuildContext context) {
    return SlideInDown(
      duration: const Duration(milliseconds: 500),
      delay: Duration(milliseconds: 100 * index),
      child: child,
    );
  }
}

class _CartState extends State<Cart> {
  ControllerCart _controller = Get.put(ControllerCart());
  var x = TextEditingController();

  @override
  Widget build(BuildContext context) {
    bool hasUnavailableProduct = _controller.cartModel!.products!.any(
      (product) =>
          product.name?.contains('***') == true || product.stock == false,
    );
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: LayoutBuilder(
        builder: (context, boxSize) {
          return GetBuilder<ControllerCart>(
            builder: (_controller) {
              return HandlingDataView(
                statusRequest: _controller.statusRequestGetCart!,
                widget: GetBuilder<ControllerCart>(
                  builder: (_controller) {
                    return _controller.cartModel != null &&
                            _controller.cartModel!.products != null &&
                            _controller.cartModel!.products!.isNotEmpty
                        ? Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: ListView(
                                  physics: const BouncingScrollPhysics(),
                                  children: [
                                    Container(
                                      margin: const EdgeInsets.symmetric(
                                          horizontal: 6, vertical: 8),
                                      child: ListView.separated(
                                        physics:
                                            const NeverScrollableScrollPhysics(),
                                        shrinkWrap: true,
                                        separatorBuilder: (context, i) =>
                                            SizedBox(
                                                height:
                                                    boxSize.maxHeight * 0.01),
                                        itemCount: _controller
                                                .cartModel!.products?.length ??
                                            0,
                                        itemBuilder: (context, i) {
                                          final delay =
                                              Duration(milliseconds: 100 * i);
                                          return SlideInDown(
                                            duration: const Duration(
                                                milliseconds: 500),
                                            delay: delay,
                                            child: ContainerProductCart(
                                              products: _controller
                                                  .cartModel!.products![i],
                                              onCart: false,
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              SizedBox(height: boxSize.maxHeight * 0.02),
                              SlideInLeft(
                                duration: const Duration(milliseconds: 500),
                                child: ApplyCouponWidget(),
                              ),
                              SizedBox(height: boxSize.maxHeight * 0.03),
                              Row(
                                children: [
                                  Icon(
                                    _controller.hasReachedTarget == true
                                        ? Icons
                                            .check_circle // الأيقونة عند الوصول إلى الشحن المجاني
                                        : Icons
                                            .delivery_dining, // الأيقونة قبل الوصول إلى الشحن المجاني
                                    size: 18,
                                    color: _controller.hasReachedTarget == true
                                        ? AppColors.primaryColor
                                        : Colors
                                            .black, // تغيير اللون بناءً على الحالة
                                  ),
                                  const SizedBox(
                                    width: 7,
                                  ),
                                  Flexible(
                                    child: Text(
                                      _controller.hasReachedTarget == true
                                          ? '189'.tr
                                          : '188'.tr,
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodySmall
                                          ?.copyWith(fontSize: 12),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: boxSize.maxHeight * 0.03),
                              CartProgressLine(
                                totalAmount: _controller.remainingAmount,
                              ), //_controller.remainingAmount!
                              SizedBox(height: boxSize.maxHeight * 0.03),
                              // قبل الزر: نحدد هل يوجد منتج غير متوفر

// الزر نفسه
                              FadeInUp(
                                duration: const Duration(milliseconds: 500),
                                child: SizedBox(
                                  height: 48,
                                  child: IgnorePointer(
                                    ignoring: hasUnavailableProduct,
                                    child: Opacity(
                                      opacity:
                                          hasUnavailableProduct ? 0.6 : 1.0,
                                      child: ButtonOnCart(
                                        width: boxSize.maxWidth * 0.80,
                                        label: hasUnavailableProduct
                                            ? '214'.tr
                                            : '54'.tr,
                                        onTap: () {
                                          _controller.plusIndexScreensCart();
                                        },
                                      ),
                                    ),
                                  ),
                                ),
                              ),

                              SizedBox(height: boxSize.maxHeight * 0.02),
                            ],
                          )
                        : Center(
                            child: Text(
                              '149'.tr,
                              style: Theme.of(context).textTheme.bodyMedium,
                              textAlign: TextAlign.center,
                            ),
                          );
                  },
                ),
                onRefresh: () {
                  _controller.getCart();
                },
              );
            },
          );
        },
      ),
    );
  }
}

class ApplyCouponWidget extends StatelessWidget {
  ApplyCouponWidget({
    super.key,
  });
  final ControllerCoupon _controller = Get.put(ControllerCoupon());

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ControllerCoupon>(builder: (_controller) {
      return Form(
        // key: _controller.formApplyCoupon,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            CustomFiledCart(
              width: MediaQuery.of(context).size.width * 0.60,
              hint: '43'.tr,
              controller: _controller.codeApplyCoupon,
              validator: (value) => value!.isEmpty ? '163'.tr : null,
            ),
            _controller.statusRequestApplyCoupon == StatusRequest.loading
                ? Center(
                    child: CircularProgressIndicator(
                      color: AppColors.primaryColor,
                    ),
                  )
                : InkWell(
                    onTap: () {
                      _controller.applyCoupon();
                    },
                    child: Container(
                      height: 45,
                      width: MediaQuery.of(context).size.width * 0.30,
                      decoration: BoxDecoration(
                          color: AppColors.primaryColor,
                          borderRadius: BorderRadius.circular(20)),
                      child: Center(
                        child: Text(
                          '44'.tr,
                          style: Theme.of(context)
                              .textTheme
                              .bodyMedium
                              ?.copyWith(color: Colors.white, fontSize: 16),
                        ),
                      ),
                    ),
                  ),
          ],
        ),
      );
    });
  }
}

void showDiscountMessage(BuildContext context, double remainingAmount) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return FadeIn(
        child: AlertDialog(
          title: Text('184'.tr, style: Theme.of(context).textTheme.bodyLarge),
          content: remainingAmount > 0
              ? RichText(
                  text: TextSpan(
                    style: Theme.of(context).textTheme.bodyMedium,
                    children: [
                      TextSpan(text: '${'181'.tr} '),
                      TextSpan(
                        text: remainingAmount.toStringAsFixed(2),
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      WidgetSpan(
                        alignment: PlaceholderAlignment.middle,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          child: Image.asset(
                            "images/riyalsymbol_compressed.png",
                            height: 14,
                          ),
                        ),
                      ),
                      TextSpan(text: ' ${'182'.tr}'),
                    ],
                  ),
                )
              : Text(
                  '183'.tr,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text(
                '185'.tr,
                style: TextStyle(color: AppColors.primaryColor),
              ),
            ),
          ],
        ),
      );
    },
  );
}

class CartProgressLine extends StatelessWidget {
  final double totalAmount; // إجمالي السلة
  final double targetAmount = 350.0; // المبلغ المستهدف

  CartProgressLine({required this.totalAmount});

  @override
  Widget build(BuildContext context) {
    // حساب النسبة المئوية من التقدم
    double progress = (totalAmount / targetAmount).clamp(0.0, 1.0);

    return LinearPercentIndicator(
      lineHeight: 5.0, // سمك الخط
      percent: progress, // النسبة المئوية للتقدم
      backgroundColor: Colors.green,
      // لون خلفية الخط
      progressColor: Colors.grey.shade300, // لون التقدم
      animation: true, // إضافة أنيميشن عند زيادة التقدم
      animationDuration: 500, // مدة الأنيميشن
      // center: Text(
      //   '${(progress * 100).toStringAsFixed(0)}%', // عرض النسبة المئوية
      //   style: TextStyle(fontSize: 12.0),
      // ),
    );
  }
}
