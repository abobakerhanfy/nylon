// import 'package:flutter/material.dart';

// class ShippingMethodsOnCart extends StatelessWidget {
//   const ShippingMethodsOnCart({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return LayoutBuilder(
//     builder: (context,constraints){
//       return Column(
//         children: [
//           Container(
//             height: constraints.maxHeight*0.25,
//             width: constraints.maxHeight*0.80,
//             color: Colors.orange,
//           )
//         ],
//       );
//     }
//     );
//   }
// }