// ignore_for_file: prefer_const_constructors

import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nylon/core/function/hindling_data_view.dart';
import 'package:nylon/core/function/status_request.dart';
import 'package:nylon/core/theme/colors_app.dart';
import 'package:nylon/core/widgets/address/fild_addess.dart';
import 'package:nylon/core/widgets/cached_network_image.dart';
import 'package:nylon/core/widgets/coutm_app_bar_tow.dart';
import 'package:nylon/core/widgets/login/dialog.dart';
import 'package:nylon/core/widgets/primary_button.dart';
import 'package:nylon/features/balance/presentation/controller/controller_balance.dart';
import 'package:nylon/features/cart/presentation/screens/widgets/button_on_cart.dart';
import 'package:nylon/features/cart/presentation/screens/widgets/row_invoice.dart';
import 'package:nylon/features/payment/data/models/payment_model.dart';
import 'package:nylon/features/payment/presentation/controller/controller_payment.dart';
import 'package:nylon/features/payment/presentation/screens/widgets/Payment_card_fild.dart';
import 'package:nylon/features/payment/presentation/screens/widgets/payment_Image.dart';

class SendOrderBalance extends StatefulWidget {
  SendOrderBalance({super.key});

  @override
  State<SendOrderBalance> createState() => _SendOrderBalanceState();
}

class _SendOrderBalanceState extends State<SendOrderBalance> {
  final ControllerBalance _controller = Get.find();
  ControllerPayment _controllerPayment = Get.put(ControllerPayment());
  @override
  void initState() {
    _controllerPayment.getPayment();
    // _controller.getProductsBalace();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      bottomNavigationBar: Container(
        height: 180,
        child: GetBuilder<ControllerBalance>(builder: (_controller) {
          return _controller.statusRequestGetCartB == StatusRequest.loading
              ? Center(
                  child: CircularProgressIndicator(
                    color: AppColors.primaryColor,
                  ),
                )
              : Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: ListView.separated(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount:
                              _controller.getTotalBalance!.totals!.length ?? 0,
                          separatorBuilder: (context, i) => SizedBox(
                                height:
                                    MediaQuery.of(context).size.height * 0.01,
                              ),
                          itemBuilder: (context, i) {
                            return invoiceRow(
                                title: _controller
                                    .getTotalBalance!.totals![i].title!,
                                price: _controller
                                    .getTotalBalance!.totals![i].text!);
                          }),
                    ),
                    _controller.statusRequestSendOrderB == StatusRequest.loading
                        ? Center(
                            child: CircularProgressIndicator(
                              color: AppColors.primaryColor,
                            ),
                          )
                        : ButtonOnCart(
                            width: MediaQuery.of(context).size.width * 0.80,
                            label: '36'.tr,
                            onTap: () async {
                              //      await _controller.sendDataUser();
                              //   await _controllerPayment.selectPayment(paymentCode:_controllerPayment.selectCodePayment);
                              //  await _controller.addOrderBalace();
                              if (_controllerPayment.selectCodePayment != '') {
                                await _controllerPayment.selectPayment(
                                    paymentCode:
                                        _controllerPayment.selectCodePayment);
                                if (_controllerPayment
                                        .statusRequestSelectPayment ==
                                    StatusRequest.success)
                                  await _controller.sendDataUser();
                                if (_controller.statusRequestSendDUser ==
                                    StatusRequest.success) {
                                  await _controllerPayment
                                      .paymentMyFatoorahBlance();
                                  // if(_controllerPayment.statusRequestpMyFatoorah==StatusRequest.success){
                                  //   await _controller.addOrderBalace();
                                  // }else{
                                  //   print("فشل الدفع ججج===================================");
                                  // }
                                } else {
                                  newCustomDialog(
                                      body: SizedBox(
                                        height: 40,
                                        child: PrimaryButton(
                                          label: 'موافق',
                                          onTap: () {
                                            Get.back();
                                          },
                                        ),
                                      ),
                                      title:
                                          'الرجاء اضافة  البيانات حتي يتم اضافة الرصيد',
                                      dialogType: DialogType.error);
                                }
                              } else {
                                newCustomDialog(
                                    body: SizedBox(
                                      height: 40,
                                      child: PrimaryButton(
                                        label: 'موافق',
                                        onTap: () {
                                          Get.back();
                                        },
                                      ),
                                    ),
                                    title:
                                        "فشل اختيار وسلية الدفع\n الراجاء الاختيار واعادة مرة اخري ",
                                    //'الرجاء اختيار وسيلة الدفع',
                                    dialogType: DialogType.error);
                              }
                            }),
                  ],
                );
        }),
      ),
      appBar: customAppBarTow(title: '123'.tr),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          const SizedBox(
            height: 10,
          ),
          Text('86'.tr,
              style: Theme.of(context)
                  .textTheme
                  .bodyMedium
                  ?.copyWith(color: Colors.black)),
          const SizedBox(
            height: 10,
          ),
          Form(
            key: _controller.formAddDataUser,
            child: Row(
              children: [
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.45,
                  child: TextFildAddess(
                      label: '87'.tr,
                      valid: (value) => value!.isEmpty ? '163'.tr : null,
                      textInputType: TextInputType.name,
                      controller: _controller.cFirstName),
                ),
                const SizedBox(
                  width: 15,
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.45,
                  child: TextFildAddess(
                      label: '88'.tr,
                      valid: (value) => value!.isEmpty ? '163'.tr : null,
                      textInputType: TextInputType.name,
                      controller: _controller.cLastName),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 20,
          ),
          //WidgetPaymentDataCart(),
          GetBuilder<ControllerPayment>(builder: (_controllerPayment) {
            return HandlingDataView(
              statusRequest: _controllerPayment.statusRequestGetPayment!,
              widget: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: MediaQuery.of(context).size.height * 0.02),
                  Text(
                    '169'.tr,
                    style: Theme.of(context)
                        .textTheme
                        .headlineSmall
                        ?.copyWith(color: Colors.black),
                  ),
                  SizedBox(height: MediaQuery.of(context).size.height * 0.02),
                  SizedBox(
                    child: ListView.separated(
                      padding: const EdgeInsets.all(8),
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      separatorBuilder: (context, i) => SizedBox(
                          height: MediaQuery.of(context).size.height * 0.02),
                      itemCount:
                          _controllerPayment.paymentsDataList.length ?? 0,
                      itemBuilder: (context, i) {
                        return _controllerPayment.paymentsDataList[i].code ==
                                    "bank_transfer" ||
                                _controllerPayment.paymentsDataList[i].code ==
                                    "tabby_installments" ||
                                _controllerPayment.paymentsDataList[i].code ==
                                    "tamarapay" ||
                                _controllerPayment.paymentsDataList[i].code ==
                                    'xpayment1'
                            ? SizedBox.shrink()
                            : ContainerPaymentDataBalance(
                                codePayment:
                                    _controllerPayment.selectCodePayment,
                                paymentsData:
                                    _controllerPayment.paymentsDataList[i],
                              );
                      },
                    ),
                  ),
                ],
              ),
              onRefresh: () {
                _controllerPayment.getPayment();
              },
            );
          }),
        ],
      ),
    );
  }
}

class ContainerPaymentDataBalance extends StatelessWidget {
  final PaymentsData paymentsData;
  final String? codePayment;

  ContainerPaymentDataBalance({
    super.key,
    required this.paymentsData,
    this.codePayment,
  });

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ControllerPayment>(
      builder: (_controller) {
        return InkWell(
          onTap: () {
            print(paymentsData.images!.length);
            _controller.selectCode(
                code: paymentsData.code!, title: paymentsData.separatedText!);
          },
          child: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.colorCreditCard,
              borderRadius: BorderRadius.circular(0),
              border: Border.all(
                color: codePayment == paymentsData.code
                    ? AppColors.primaryColor
                    : AppColors.colorCreditCard,
                width: 2,
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      if (paymentsData.images != null &&
                          paymentsData.images!.length == 1) ...{
                        SizedBox(
                          height: 50,
                          child: CachedNetworkImageWidget(
                              fit: BoxFit.cover,
                              imageUrl: paymentsData.images!.first ?? ''),

                          //  PaymentImageWidget(imageUrl: paymentsData.images!.first),
                        ),
                      },

                      // الحالة عندما يكون هناك أكثر من صورة
                      if (paymentsData.images != null &&
                          paymentsData.images!.length > 1)
                        Flexible(
                          //   width: MediaQuery.of(context).size.width * 0.90,
                          // height:paymentsData.images!.length > 1? 110:50,
                          child: Container(
                            width: MediaQuery.of(context).size.width * 0.90,
                            padding: const EdgeInsets.all(0),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment
                                  .start, // تحديد حجم العمود بناءً على المحتوى
                              children: [
                                SizedBox(
                                  height: 30, // تحديد ارتفاع ثابت للقائمة
                                  child: ListView.separated(
                                    shrinkWrap: true,
                                    scrollDirection: Axis.horizontal,
                                    separatorBuilder: (context, i) =>
                                        const SizedBox(width: 7),
                                    itemCount: paymentsData.images!.length ?? 0,
                                    itemBuilder: (context, i) {
                                      return PaymentImageWidget(
                                          imageUrl: paymentsData.images![i]);
                                    },
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  paymentsData.separatedText != null
                                      ? paymentsData.separatedText!
                                      : '',
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodySmall
                                      ?.copyWith(
                                        fontSize: 12,
                                        color: const Color.fromARGB(
                                            255, 31, 27, 27),
                                      ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 5),
                                if (codePayment == paymentsData.code)
                                  Icon(
                                    Icons.check_circle,
                                    color: AppColors.primaryColor,
                                  ),
                              ],
                            ),
                          ),
                        ),

                      if (paymentsData.images != null &&
                              paymentsData.images!.length == 1 ||
                          paymentsData.images!.isEmpty) ...{
                        SizedBox(
                          width: MediaQuery.of(context).size.width * 0.40,
                          child: Text(
                            paymentsData.separatedText != null
                                ? paymentsData.separatedText!
                                : '',
                            style: Theme.of(context)
                                .textTheme
                                .bodySmall
                                ?.copyWith(
                                  fontSize: 12,
                                  color: const Color.fromARGB(255, 31, 27, 27),
                                ),
                            maxLines: 4,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const Spacer(),
                        if (codePayment == paymentsData.code)
                          Icon(
                            Icons.check_circle,
                            color: AppColors.primaryColor,
                          ),
                      }
                    ],
                  ),
                  if (_controller.selectCodePayment == "myfatoorah_pg" &&
                      paymentsData.code == "myfatoorah_pg") ...{
                    PaymentCardField()
                  }
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
