class SelectPaymentModel {
  int? sessionData;
  String? success;
  int? orderId;
  dynamic webUrl;

  SelectPaymentModel({this.sessionData, this.success, this.orderId, this.webUrl});

  SelectPaymentModel.fromJson(Map<String, dynamic> json) {
    sessionData = json['session_data'];
    success = json['success'];
    orderId = json['order_id'];
    webUrl = json['web_url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['session_data'] = this.sessionData;
    data['success'] = this.success;
    data['order_id'] = this.orderId;
    data['web_url'] = this.webUrl;
    return data;
  }
}