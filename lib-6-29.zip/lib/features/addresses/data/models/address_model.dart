// class Address {
//   String? addressId;
//   String? firstname;
//   String? lastname;
//   String? company;
//   String? address1;
//   String? address2;
//   String? postcode;
//   String? city;
//   String? zoneId;
//   String? zone;
//   String? zoneCode;
//   String? countryId;
//   String? country;
//   String? isoCode2;
//   String? isoCode3;
//   String? addressFormat;
//   String? customField;

//   Address({
//     this.addressId,
//     this.firstname,
//     this.lastname,
//     this.company,
//     this.address1,
//     this.address2,
//     this.postcode,
//     this.city,
//     this.zoneId,
//     this.zone,
//     this.zoneCode,
//     this.countryId,
//     this.country,
//     this.isoCode2,
//     this.isoCode3,
//     this.addressFormat,
//     this.customField,
//   });

//   factory Address.fromJson(Map<String, dynamic> json) {
//     return Address(
//       addressId: json['address_id'],
//       firstname: json['firstname'],
//       lastname: json['lastname'],
//       company: json['company'],
//       address1: json['address_1'],
//       address2: json['address_2'],
//       postcode: json['postcode'],
//       city: json['city'],
//       zoneId: json['zone_id'],
//       zone: json['zone'],
//       zoneCode: json['zone_code'],
//       countryId: json['country_id'],
//       country: json['country'],
//       isoCode2: json['iso_code_2'],
//       isoCode3: json['iso_code_3'],
//       addressFormat: json['address_format'],
//       customField: json['custom_field'],
//     );
//   }
// }
class AddressModel {
  String? success;
  Data? data;

  AddressModel({this.success, this.data});

  AddressModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  CustomerData? customerData;
  List<Address>? address;

  Data({this.customerData, this.address});

  Data.fromJson(Map<String, dynamic> json) {
    customerData = json['customer_data'] != null
        ? new CustomerData.fromJson(json['customer_data'])
        : null;
    if (json['address'] != null) {
      address = <Address>[];
      json['address'].forEach((v) {
        address!.add(new Address.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.customerData != null) {
      data['customer_data'] = this.customerData!.toJson();
    }
    if (this.address != null) {
      data['address'] = this.address!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class CustomerData {
  String? customerId;
  String? customerGroupId;
  String? storeId;
  String? languageId;
  String? firstname;
  String? lastname;
  String? email;
  String? telephone;
  String? fax;
  String? password;
  String? salt;
 dynamic cart;
 dynamic wishlist;
  String? newsletter;
  String? addressId;
  String? customField;
  String? ip;
  String? status;
  String? safe;
  String? token;
  String? code;
  String? dateAdded;
  dynamic telephoneStatus;
  String? activation;
  String? activeCode;
  dynamic typelogin;
  String? dateModified;
  String? image;

  CustomerData(
      {this.customerId,
      this.customerGroupId,
      this.storeId,
      this.languageId,
      this.firstname,
      this.lastname,
      this.email,
      this.telephone,
      this.fax,
      this.password,
      this.salt,
      this.cart,
      this.wishlist,
      this.newsletter,
      this.addressId,
      this.customField,
      this.ip,
      this.status,
      this.safe,
      this.token,
      this.code,
      this.dateAdded,
      this.telephoneStatus,
      this.activation,
      this.activeCode,
      this.typelogin,
      this.dateModified,
      this.image});

  CustomerData.fromJson(Map<String, dynamic> json) {
    customerId = json['customer_id'];
    customerGroupId = json['customer_group_id'];
    storeId = json['store_id'];
    languageId = json['language_id'];
    firstname = json['firstname'];
    lastname = json['lastname'];
    email = json['email'];
    telephone = json['telephone'];
    fax = json['fax'];
    password = json['password'];
    salt = json['salt'];
    cart = json['cart'];
    wishlist = json['wishlist'];
    newsletter = json['newsletter'];
    addressId = json['address_id'];
    customField = json['custom_field'];
    ip = json['ip'];
    status = json['status'];
    safe = json['safe'];
    token = json['token'];
    code = json['code'];
    dateAdded = json['date_added'];
    telephoneStatus = json['telephone_status'];
    activation = json['activation'];
    activeCode = json['active_code'];
    typelogin = json['typelogin'];
    dateModified = json['date_modified'];
    image = json['image'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['customer_id'] = this.customerId;
    data['customer_group_id'] = this.customerGroupId;
    data['store_id'] = this.storeId;
    data['language_id'] = this.languageId;
    data['firstname'] = this.firstname;
    data['lastname'] = this.lastname;
    data['email'] = this.email;
    data['telephone'] = this.telephone;
    data['fax'] = this.fax;
    data['password'] = this.password;
    data['salt'] = this.salt;
    data['cart'] = this.cart;
    data['wishlist'] = this.wishlist;
    data['newsletter'] = this.newsletter;
    data['address_id'] = this.addressId;
    data['custom_field'] = this.customField;
    data['ip'] = this.ip;
    data['status'] = this.status;
    data['safe'] = this.safe;
    data['token'] = this.token;
    data['code'] = this.code;
    data['date_added'] = this.dateAdded;
    data['telephone_status'] = this.telephoneStatus;
    data['activation'] = this.activation;
    data['active_code'] = this.activeCode;
    data['typelogin'] = this.typelogin;
    data['date_modified'] = this.dateModified;
    data['image'] = this.image;
    return data;
  }
}

class Address {
  String? addressId;
  String? customerId;
  String? firstname;
  String? lastname;
  String? company;
  String? address1;
  String? address2;
  String? city;
  String? postcode;
  String? countryId;
  String? zoneId;
  String? customField;
  String? phone;
  String? phoneStatus;
  String? countryShortName;
  String? province;
  String? neighborhood;
  String? street;
  String? streetNumber;
  String? postalCodeSuffix;
  String? country;
  String? addressDefault;

  Address(
      {this.addressId,
      this.customerId,
      this.firstname,
      this.lastname,
      this.company,
      this.address1,
      this.address2,
      this.city,
      this.postcode,
      this.countryId,
      this.zoneId,
      this.customField,
      this.phone,
      this.phoneStatus,
      this.countryShortName,
      this.province,
      this.neighborhood,
      this.street,
      this.streetNumber,
      this.postalCodeSuffix,
      this.country,
      this.addressDefault});

  Address.fromJson(Map<String, dynamic> json) {
    addressId = json['address_id'];
    customerId = json['customer_id'];
    firstname = json['firstname'];
    lastname = json['lastname'];
    company = json['company'];
    address1 = json['address_1'];
    address2 = json['address_2'];
    city = json['city'];
    postcode = json['postcode'];
    countryId = json['country_id'];
    zoneId = json['zone_id'];
    customField = json['custom_field'];
    phone = json['phone'];
    phoneStatus = json['phone_status'];
    countryShortName = json['country_short_name'];
    province = json['province'];
    neighborhood = json['neighborhood'];
    street = json['street'];
    streetNumber = json['street_number'];
    postalCodeSuffix = json['postal_code_suffix'];
    country = json['country'];
    addressDefault = json['address_default'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['address_id'] = this.addressId;
    data['customer_id'] = this.customerId;
    data['firstname'] = this.firstname;
    data['lastname'] = this.lastname;
    data['company'] = this.company;
    data['address_1'] = this.address1;
    data['address_2'] = this.address2;
    data['city'] = this.city;
    data['postcode'] = this.postcode;
    data['country_id'] = this.countryId;
    data['zone_id'] = this.zoneId;
    data['custom_field'] = this.customField;
    data['phone'] = this.phone;
    data['phone_status'] = this.phoneStatus;
    data['country_short_name'] = this.countryShortName;
    data['province'] = this.province;
    data['neighborhood'] = this.neighborhood;
    data['street'] = this.street;
    data['street_number'] = this.streetNumber;
    data['postal_code_suffix'] = this.postalCodeSuffix;
    data['country'] = this.country;
    data['address_default'] = this.addressDefault;
    return data;
  }
}
