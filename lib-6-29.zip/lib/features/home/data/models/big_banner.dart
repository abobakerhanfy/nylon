
class BigBanner {
  String? en;
  String? ar;
  String? imageEn;
  String? imageAr;
  String? categories;
  String? status;
  String? sort;

  BigBanner(
      {this.en,
      this.ar,
      this.imageEn,
      this.imageAr,
      this.categories,
      this.status,
      this.sort});
 int getSortOrder() {
    // قد تحتاج لتحويل `sort` إلى قيمة عددية
    return int.tryParse(sort ?? '0') ?? 0;
  }
  BigBanner.fromJson(Map<String, dynamic> json) {
    en = json['en'];
    ar = json['ar'];
    imageEn = json['image_en'];
    imageAr = json['image_ar'];
    categories = json['categories'];
    status = json['status'];
    sort = json['sort'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['en'] = this.en;
    data['ar'] = this.ar;
    data['image_en'] = this.imageEn;
    data['image_ar'] = this.imageAr;
    data['categories'] = this.categories;
    data['status'] = this.status;
    data['sort'] = this.sort;
    return data;
  }
}
