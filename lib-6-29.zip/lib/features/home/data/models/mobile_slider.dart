class MobileSlider {
  List<ImageData>? image;
  String? status;
  String? sort;

  MobileSlider({this.image, this.status, this.sort});
   int getSortOrder() {
    // قد تحتاج لتحويل `sortOrder` إلى قيمة عددية
    return int.tryParse(sort ?? '0') ?? 0;
  
}

  MobileSlider.fromJson(Map<String, dynamic> json) {
    if (json['image'] != null) {
      image = <ImageData>[];
      json['image'].forEach((v) {
        image!.add(new ImageData.fromJson(v));
      });
    }
    status = json['status'];
    sort = json['sort'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.image != null) {
      data['image'] = this.image!.map((v) => v.toJson()).toList();
    }
    data['status'] = this.status;
    data['sort'] = this.sort;
    return data;
  }
}

class ImageData {
    String? image;
  String? link;
  String? sortOrder;

  ImageData({this.image, this.link, this.sortOrder});
   int getSortOrder() {
    // قد تحتاج لتحويل `sortOrder` إلى قيمة عددية
    return int.tryParse(sortOrder ?? '0') ?? 0;
  }

  ImageData.fromJson(Map<String, dynamic> json) {
    image = json['image'];
    link = json['link'];
    sortOrder = json['sort_order'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['image'] = this.image;
    data['link'] = this.link;
    data['sort_order'] = this.sortOrder;
    return data;
  }
}