
class SlidersModel {
  String? name;
  List<Sliders>? sliders;
  String? stauts;

  SlidersModel({this.name, this.sliders, this.stauts});

  SlidersModel.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    if (json['sliders'] != null) {
      sliders = <Sliders>[];
      json['sliders'].forEach((v) {
        sliders!.add(new Sliders.fromJson(v));
      });
    }
    stauts = json['stauts'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    if (this.sliders != null) {
      data['sliders'] = this.sliders!.map((v) => v.toJson()).toList();
    }
    data['stauts'] = this.stauts;
    return data;
  }
}

class Sliders {
  String? name;
  String? link;

  Sliders({this.name, this.link});

  Sliders.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    link = json['link'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['link'] = this.link;
    return data;
  }
}