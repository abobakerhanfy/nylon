class TrackingShipping {
  Data? data;
  bool? success;

  TrackingShipping({this.data, this.success});

  TrackingShipping.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
    success = json['success'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['success'] = this.success;
    return data;
  }
}

class Data {
  String? invoiceNo;
  String? orderId;
  String? orderShippingId;
  String? dateAdded;
  String? paymentMethod;
  String? shippingMethod;
  List<Products>? products;
  List<Totals>? totals;
  String? comment;
  List<Histories>? histories;

  Data(
      {this.invoiceNo,
      this.orderId,
      this.orderShippingId,
      this.dateAdded,
      this.paymentMethod,
      this.shippingMethod,
      this.products,
      this.totals,
      this.comment,
      this.histories});

  Data.fromJson(Map<String, dynamic> json) {
    invoiceNo = json['invoice_no'];
    orderId = json['order_id'];
    orderShippingId = json['order_shipping_id'];
    dateAdded = json['date_added'];
    paymentMethod = json['payment_method'];
    shippingMethod = json['shipping_method'];
    if (json['products'] != null) {
      products = <Products>[];
      json['products'].forEach((v) {
        products!.add(new Products.fromJson(v));
      });
    }
 
    if (json['totals'] != null) {
      totals = <Totals>[];
      json['totals'].forEach((v) {
        totals!.add(new Totals.fromJson(v));
      });
    }
    comment = json['comment'];
    if (json['histories'] != null) {
      histories = <Histories>[];
      json['histories'].forEach((v) {
        histories!.add(new Histories.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['invoice_no'] = this.invoiceNo;
    data['order_id'] = this.orderId;
    data['order_shipping_id'] = this.orderShippingId;
    data['date_added'] = this.dateAdded;
    data['payment_method'] = this.paymentMethod;
    data['shipping_method'] = this.shippingMethod;
    if (this.products != null) {
      data['products'] = this.products!.map((v) => v.toJson()).toList();
    }
    if (this.totals != null) {
      data['totals'] = this.totals!.map((v) => v.toJson()).toList();
    }
    data['comment'] = this.comment;
    if (this.histories != null) {
      data['histories'] = this.histories!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Products {
  String? href;
  String? name;
  String? model;
  String? quantity;
  String? price;
  String? total;

  Products(
      {this.href,
      this.name,
      this.model,
      this.quantity,
      this.price,
      this.total});

  Products.fromJson(Map<String, dynamic> json) {
    href = json['href'];
    name = json['name'];
    model = json['model'];
    quantity = json['quantity'];
    price = json['price'];
    total = json['total'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['href'] = this.href;
    data['name'] = this.name;
    data['model'] = this.model;
   
    data['quantity'] = this.quantity;
    data['price'] = this.price;
    data['total'] = this.total;
    return data;
  }
}

class Totals {
  String? title;
  String? text;

  Totals({this.title, this.text});

  Totals.fromJson(Map<String, dynamic> json) {
    title = json['title'];
    text = json['text'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['title'] = this.title;
    data['text'] = this.text;
    return data;
  }
}

class Histories {
  String? dateAdded;
  String? status;
  String? comment;

  Histories({this.dateAdded, this.status, this.comment});

  Histories.fromJson(Map<String, dynamic> json) {
    dateAdded = json['date_added'];
    status = json['status'];
    comment = json['comment'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['date_added'] = this.dateAdded;
    data['status'] = this.status;
    data['comment'] = this.comment;
    return data;
  }
}