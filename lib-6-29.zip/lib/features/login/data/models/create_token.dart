class CreateTokenModel {
  String? success;
  String? apiId;
  String? apiToken;

  CreateTokenModel({this.success, this.apiId, this.apiToken});

  CreateTokenModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    apiId = json['api_id'];
    apiToken = json['api_token'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    data['api_id'] = this.apiId;
    data['api_token'] = this.apiToken;
    return data;
  }
}