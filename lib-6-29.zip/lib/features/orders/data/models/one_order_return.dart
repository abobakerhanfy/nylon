class ReturnOneOrder {
  String? success;
  List<ModelDataOrder>? data;

  ReturnOneOrder({this.success, this.data});

  ReturnOneOrder.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['data'] != null) {
      data = <ModelDataOrder>[];
      json['data'].forEach((v) {
        data!.add(new ModelDataOrder.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ModelDataOrder {
  Data? orderdata;
  List<History>? history;
  List<Shipping>? shipping;

  ModelDataOrder({this.orderdata, this.history, this.shipping});

  ModelDataOrder.fromJson(Map<String, dynamic> json) {
    orderdata = json['data'] != null ? new Data.fromJson(json['data']) : null;
    if (json['history'] != null) {
      history = <History>[];
      json['history'].forEach((v) {
        history!.add(new History.fromJson(v));
      });
    }
    if (json['shipping'] != null) {
      shipping = <Shipping>[];
      json['shipping'].forEach((v) {
        shipping!.add(new Shipping.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.orderdata != null) {
      data['data'] = this.orderdata!.toJson();
    }
    if (this.history != null) {
      data['history'] = this.history!.map((v) => v.toJson()).toList();
    }
    if (this.shipping != null) {
      data['shipping'] = this.shipping!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  String? returnId;
  String? orderId;
  String? firstname;
  String? lastname;
  String? email;
  String? telephone;
  String? product;
  String? model;
  String? quantity;
  String? opened;
  String? reason;
  String? action;
  String? status;
  String? comment;
  String? dateOrdered;
  String? dateAdded;
  String? dateModified;

  Data(
      {this.returnId,
      this.orderId,
      this.firstname,
      this.lastname,
      this.email,
      this.telephone,
      this.product,
      this.model,
      this.quantity,
      this.opened,
      this.reason,
      this.action,
      this.status,
      this.comment,
      this.dateOrdered,
      this.dateAdded,
      this.dateModified});

  Data.fromJson(Map<String, dynamic> json) {
    returnId = json['return_id'];
    orderId = json['order_id'];
    firstname = json['firstname'];
    lastname = json['lastname'];
    email = json['email'];
    telephone = json['telephone'];
    product = json['product'];
    model = json['model'];
    quantity = json['quantity'];
    opened = json['opened'];
    reason = json['reason'];
    action = json['action'];
    status = json['status'];
    comment = json['comment'];
    dateOrdered = json['date_ordered'];
    dateAdded = json['date_added'];
    dateModified = json['date_modified'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['return_id'] = this.returnId;
    data['order_id'] = this.orderId;
    data['firstname'] = this.firstname;
    data['lastname'] = this.lastname;
    data['email'] = this.email;
    data['telephone'] = this.telephone;
    data['product'] = this.product;
    data['model'] = this.model;
    data['quantity'] = this.quantity;
    data['opened'] = this.opened;
    data['reason'] = this.reason;
    data['action'] = this.action;
    data['status'] = this.status;
    data['comment'] = this.comment;
    data['date_ordered'] = this.dateOrdered;
    data['date_added'] = this.dateAdded;
    data['date_modified'] = this.dateModified;
    return data;
  }
}

class History {
  String? returnHistoryId;
  String? returnId;
  String? returnStatusId;
  String? notify;
  String? comment;
  String? dateAdded;

  History(
      {this.returnHistoryId,
      this.returnId,
      this.returnStatusId,
      this.notify,
      this.comment,
      this.dateAdded});

  History.fromJson(Map<String, dynamic> json) {
    returnHistoryId = json['return_history_id'];
    returnId = json['return_id'];
    returnStatusId = json['return_status_id'];
    notify = json['notify'];
    comment = json['comment'];
    dateAdded = json['date_added'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['return_history_id'] = this.returnHistoryId;
    data['return_id'] = this.returnId;
    data['return_status_id'] = this.returnStatusId;
    data['notify'] = this.notify;
    data['comment'] = this.comment;
    data['date_added'] = this.dateAdded;
    return data;
  }
}

class Shipping {
  String? shippingAddress1;

  Shipping({this.shippingAddress1});

  Shipping.fromJson(Map<String, dynamic> json) {
    shippingAddress1 = json['shipping_address_1'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['shipping_address_1'] = this.shippingAddress1;
    return data;
  }
}