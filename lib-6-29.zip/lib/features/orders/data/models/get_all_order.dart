class ModelAllOrder {
  List<Order>? data;
  String? success;

  ModelAllOrder({this.data, this.success});

  ModelAllOrder.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <Order>[];
      json['data'].forEach((v) {
        data!.add(new Order.fromJson(v));
      });
    }
    success = json['success'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    data['success'] = this.success;
    return data;
  }
}

class Order {
  String? orderId;
  String? invoiceNo;
  String? invoicePrefix;
  String? orderShippingId;
  String? storeId;
  String? storeName;
  String? storeUrl;
  String? customerId;
  String? firstname;
  String? lastname;
  String? telephone;
  String? email;
  String? paymentFirstname;
  String? paymentLastname;
  String? paymentCompany;
  String? paymentAddress1;
  String? paymentAddress2;
  String? paymentPostcode;
  String? paymentCity;
  String? paymentZoneId;
  String? paymentZone;
  String? paymentZoneCode;
  String? paymentCountryId;
  String? paymentCountry;
  String? paymentIsoCode2;
  String? paymentIsoCode3;
  String? paymentAddressFormat;
  String? paymentMethod;
  String? shippingFirstname;
  String? shippingLastname;
  String? shippingCompany;
  String? shippingAddress1;
  String? shippingAddress2;
  String? shippingPostcode;
  String? shippingCity;
  String? shippingZoneId;
  String? shippingZone;
  String? shippingZoneCode;
  String? shippingCountryId;
  String? shippingCountry;
  String? shippingIsoCode2;
  String? shippingIsoCode3;
  String? shippingAddressFormat;
  String? shippingMethod;
  String? comment;
  String? total;
  String? orderStatusId;
  String? orderStatus;
  String? languageId;
  String? currencyId;
  String? currencyCode;
  String? currencyValue;
  String? dateModified;
  String? dateAdded;
  String? ip;

  Order(
      {this.orderId,
      this.invoiceNo,
      this.invoicePrefix,
      this.orderShippingId,
      this.storeId,
      this.storeName,
      this.storeUrl,
      this.customerId,
      this.firstname,
      this.lastname,
      this.telephone,
      this.email,
      this.orderStatus,
      this.paymentFirstname,
      this.paymentLastname,
      this.paymentCompany,
      this.paymentAddress1,
      this.paymentAddress2,
      this.paymentPostcode,
      this.paymentCity,
      this.paymentZoneId,
      this.paymentZone,
      this.paymentZoneCode,
      this.paymentCountryId,
      this.paymentCountry,
      this.paymentIsoCode2,
      this.paymentIsoCode3,
      this.paymentAddressFormat,
      this.paymentMethod,
      this.shippingFirstname,
      this.shippingLastname,
      this.shippingCompany,
      this.shippingAddress1,
      this.shippingAddress2,
      this.shippingPostcode,
      this.shippingCity,
      this.shippingZoneId,
      this.shippingZone,
      this.shippingZoneCode,
      this.shippingCountryId,
      this.shippingCountry,
      this.shippingIsoCode2,
      this.shippingIsoCode3,
      this.shippingAddressFormat,
      this.shippingMethod,
      this.comment,
      this.total,
      this.orderStatusId,
      this.languageId,
      this.currencyId,
      this.currencyCode,
      this.currencyValue,
      this.dateModified,
      this.dateAdded,
      this.ip});

  Order.fromJson(Map<String, dynamic> json) {
    orderId = json['order_id'];
    invoiceNo = json['invoice_no'];
    invoicePrefix = json['invoice_prefix'];
    orderShippingId = json['order_shipping_id'];
    storeId = json['store_id'];
    storeName = json['store_name'];
    storeUrl = json['store_url'];
    customerId = json['customer_id'];
    firstname = json['firstname'];
    lastname = json['lastname'];
    telephone = json['telephone'];
    email = json['email'];
    orderStatus = json['order_status'];
    paymentFirstname = json['payment_firstname'];
    paymentLastname = json['payment_lastname'];
    paymentCompany = json['payment_company'];
    paymentAddress1 = json['payment_address_1'];
    paymentAddress2 = json['payment_address_2'];
    paymentPostcode = json['payment_postcode'];
    paymentCity = json['payment_city'];
    paymentZoneId = json['payment_zone_id'];
    paymentZone = json['payment_zone'];
    paymentZoneCode = json['payment_zone_code'];
    paymentCountryId = json['payment_country_id'];
    paymentCountry = json['payment_country'];
    paymentIsoCode2 = json['payment_iso_code_2'];
    paymentIsoCode3 = json['payment_iso_code_3'];
    paymentAddressFormat = json['payment_address_format'];
    paymentMethod = json['payment_method'];
    shippingFirstname = json['shipping_firstname'];
    shippingLastname = json['shipping_lastname'];
    shippingCompany = json['shipping_company'];
    shippingAddress1 = json['shipping_address_1'];
    shippingAddress2 = json['shipping_address_2'];
    shippingPostcode = json['shipping_postcode'];
    shippingCity = json['shipping_city'];
    shippingZoneId = json['shipping_zone_id'];
    shippingZone = json['shipping_zone'];
    shippingZoneCode = json['shipping_zone_code'];
    shippingCountryId = json['shipping_country_id'];
    shippingCountry = json['shipping_country'];
    shippingIsoCode2 = json['shipping_iso_code_2'];
    shippingIsoCode3 = json['shipping_iso_code_3'];
    shippingAddressFormat = json['shipping_address_format'];
    shippingMethod = json['shipping_method'];
    comment = json['comment'];
    total = json['total'];
    orderStatusId = json['order_status_id'];
    languageId = json['language_id'];
    currencyId = json['currency_id'];
    currencyCode = json['currency_code'];
    currencyValue = json['currency_value'];
    dateModified = json['date_modified'];
    dateAdded = json['date_added'];
    ip = json['ip'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['order_id'] = this.orderId;
    data['invoice_no'] = this.invoiceNo;
    data['invoice_prefix'] = this.invoicePrefix;
    data['order_shipping_id'] = this.orderShippingId;
    data['store_id'] = this.storeId;
    data['store_name'] = this.storeName;
    data['store_url'] = this.storeUrl;
    data['customer_id'] = this.customerId;
    data['firstname'] = this.firstname;
    data['lastname'] = this.lastname;
    data['telephone'] = this.telephone;
    data['email'] = this.email;
    data['payment_firstname'] = this.paymentFirstname;
    data['payment_lastname'] = this.paymentLastname;
    data['payment_company'] = this.paymentCompany;
    data['payment_address_1'] = this.paymentAddress1;
    data['payment_address_2'] = this.paymentAddress2;
    data['payment_postcode'] = this.paymentPostcode;
    data['payment_city'] = this.paymentCity;
    data['payment_zone_id'] = this.paymentZoneId;
    data['payment_zone'] = this.paymentZone;
    data['payment_zone_code'] = this.paymentZoneCode;
    data['payment_country_id'] = this.paymentCountryId;
    data['payment_country'] = this.paymentCountry;
    data['payment_iso_code_2'] = this.paymentIsoCode2;
    data['payment_iso_code_3'] = this.paymentIsoCode3;
    data['payment_address_format'] = this.paymentAddressFormat;
    data['payment_method'] = this.paymentMethod;
    data['shipping_firstname'] = this.shippingFirstname;
    data['shipping_lastname'] = this.shippingLastname;
    data['shipping_company'] = this.shippingCompany;
    data['shipping_address_1'] = this.shippingAddress1;
    data['shipping_address_2'] = this.shippingAddress2;
    data['shipping_postcode'] = this.shippingPostcode;
    data['shipping_city'] = this.shippingCity;
    data['shipping_zone_id'] = this.shippingZoneId;
    data['shipping_zone'] = this.shippingZone;
    data['shipping_zone_code'] = this.shippingZoneCode;
    data['shipping_country_id'] = this.shippingCountryId;
    data['shipping_country'] = this.shippingCountry;
    data['shipping_iso_code_2'] = this.shippingIsoCode2;
    data['shipping_iso_code_3'] = this.shippingIsoCode3;
    data['shipping_address_format'] = this.shippingAddressFormat;
    data['shipping_method'] = this.shippingMethod;
    data['comment'] = this.comment;
    data['total'] = this.total;
    data['order_status_id'] = this.orderStatusId;
    data['language_id'] = this.languageId;
    data['currency_id'] = this.currencyId;
    data['currency_code'] = this.currencyCode;
    data['currency_value'] = this.currencyValue;
    data['date_modified'] = this.dateModified;
    data['date_added'] = this.dateAdded;
    data['ip'] = this.ip;
    return data;
  }
}