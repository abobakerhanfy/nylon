class ReturnOrdersResponse {
  String? success;
  List<Data>? data;

  ReturnOrdersResponse({this.success, this.data});

  ReturnOrdersResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(new Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  String? returnId;
  String? orderId;
  String? productId;
  String? customerId;
  String? firstname;
  String? lastname;
  String? email;
  String? telephone;
  String? product;
  String? quantity;
  String? returnReasonId;
  String? returnReasonCode;
  String? returnActionId;
  String? returnActionCode;
  String? returnStatusId;
  String? returnStatusCode;
  String? comment;
  String? dateAdded;
  String? name;
  List<History>? history;
  String? address;

  Data(
      {this.returnId,
      this.orderId,
      this.productId,
      this.customerId,
      this.firstname,
      this.lastname,
      this.email,
      this.telephone,
      this.product,
      this.quantity,
      this.returnReasonId,
      this.returnReasonCode,
      this.returnActionId,
      this.returnActionCode,
      this.returnStatusId,
      this.returnStatusCode,
      this.comment,
      this.dateAdded,
      this.name,
      this.history,
      this.address});

  Data.fromJson(Map<String, dynamic> json) {
    returnId = json['return_id'];
    orderId = json['order_id'];
    productId = json['product_id'];
    customerId = json['customer_id'];
    firstname = json['firstname'];
    lastname = json['lastname'];
    email = json['email'];
    telephone = json['telephone'];
    product = json['product'];
    quantity = json['quantity'];
    returnReasonId = json['return_reason_id'];
    returnReasonCode = json['return_reason_code'];
    returnActionId = json['return_action_id'];
    returnActionCode = json['return_action_code'];
    returnStatusId = json['return_status_id'];
    returnStatusCode = json['return_status_code'];
    comment = json['comment'];
    dateAdded = json['date_added'];
    name = json['name'];
    if (json['History'] != null) {
      history = <History>[];
      json['History'].forEach((v) {
        history!.add(new History.fromJson(v));
      });
    }
    address = json['address'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['return_id'] = this.returnId;
    data['order_id'] = this.orderId;
    data['product_id'] = this.productId;
    data['customer_id'] = this.customerId;
    data['firstname'] = this.firstname;
    data['lastname'] = this.lastname;
    data['email'] = this.email;
    data['telephone'] = this.telephone;
    data['product'] = this.product;
    data['quantity'] = this.quantity;
    data['return_reason_id'] = this.returnReasonId;
    data['return_reason_code'] = this.returnReasonCode;
    data['return_action_id'] = this.returnActionId;
    data['return_action_code'] = this.returnActionCode;
    data['return_status_id'] = this.returnStatusId;
    data['return_status_code'] = this.returnStatusCode;
    data['comment'] = this.comment;
    data['date_added'] = this.dateAdded;
    data['name'] = this.name;
    if (this.history != null) {
      data['History'] = this.history!.map((v) => v.toJson()).toList();
    }
    data['address'] = this.address;
    return data;
  }
}

class History {
  String? returnHistoryId;
  String? returnId;
  String? returnStatusId;
  String? notify;
  String? comment;
  String? dateAdded;

  History(
      {this.returnHistoryId,
      this.returnId,
      this.returnStatusId,
      this.notify,
      this.comment,
      this.dateAdded});

  History.fromJson(Map<String, dynamic> json) {
    returnHistoryId = json['return_history_id'];
    returnId = json['return_id'];
    returnStatusId = json['return_status_id'];
    notify = json['notify'];
    comment = json['comment'];
    dateAdded = json['date_added'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['return_history_id'] = this.returnHistoryId;
    data['return_id'] = this.returnId;
    data['return_status_id'] = this.returnStatusId;
    data['notify'] = this.notify;
    data['comment'] = this.comment;
    data['date_added'] = this.dateAdded;
    return data;
  }
}