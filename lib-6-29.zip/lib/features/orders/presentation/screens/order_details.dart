import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nylon/core/function/hindling_data_view.dart';
import 'package:nylon/core/routes/name_pages.dart';
import 'package:nylon/core/theme/colors_app.dart';
import 'package:nylon/core/widgets/coutm_app_bar_tow.dart';
import 'package:nylon/features/cart/presentation/screens/widgets/row_invoice.dart';
import 'package:nylon/features/orders/presentation/controller/controller_order.dart';
import 'package:nylon/features/orders/presentation/screens/widgets/Items_on_orders.dart';
import 'package:nylon/features/orders/presentation/screens/widgets/bottom_on_order.dart';
import 'package:nylon/features/orders/presentation/screens/widgets/view_addres_details.dart';

class OrderDetails extends StatelessWidget {
  OrderDetails({super.key});
 final ControllerOrder _controller = Get.find();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      bottomNavigationBar: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        color: Colors.white,
        margin: const EdgeInsets.all(10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            BottomOnOrder(
              title: "103".tr,
              onTap: (){},
              textColor: AppColors.colorTextBlckNew,
             colorBorder: AppColors.primaryColor),
               BottomOnOrder(
              title:'104'.tr,
              onTap: (){
                _controller.getNameAndModelList();
                Get.toNamed(NamePages.pSendComplaints);
              },
              textColor: AppColors.colorRed,
             colorBorder: AppColors.colorRed),
      ],),
      ),
      appBar: customAppBarTow(title: '102'.tr),
      body: Container(
        padding: const EdgeInsets.all(16),
        width: double.infinity,
        height: MediaQuery.of(context).size.height,
        child: LayoutBuilder(
          builder: (context,boxSize){
            return GetBuilder<ControllerOrder>(
              builder: (_controller) {
                return HandlingDataView(
                  statusRequest: _controller.statusRequestOneOrder!,
                  widget: GetBuilder<ControllerOrder>(
                    builder: (_controller) {
                      return ListView(
                        children: [
                            ItemsMyOrdersWidget(
                            products: _controller.oneOrderModel!.data!.products??[],
                           ),
                           SizedBox(height: boxSize.maxHeight*0.02,),
                         AddressShippingDetailsOrder(orderData: _controller.oneOrderModel!.data!,),
                            SizedBox(height: boxSize.maxHeight*0.02,),
                         //   const ContaineronOrderInvoice(),
                            SizedBox(height: boxSize.maxHeight*0.02,),
                              Padding(
                                padding: const EdgeInsets.all(8),
                                child: 
                                    ListView.separated(
                                      shrinkWrap: true,
                                      physics:const  NeverScrollableScrollPhysics(),
                                       itemCount:  _controller.oneOrderModel!.data!.totalData?.length??0,
                                       separatorBuilder:(context,i)=> SizedBox(height:MediaQuery.of(context).size.height*0.01,),
                                      itemBuilder: (context,i){
                                        return  invoiceRow(title: _controller.oneOrderModel!.data!.totalData![i].title!,
                                        price:'${_controller.oneOrderModel!.data!.totalData![i].text.toString()} ${'11'.tr}');
                                      }
                                      ),),
                           
                        ],
                      );
                    }
                  ),
                  onRefresh: (){
                    // _controller.getOneOrder(idOrder: idOrder);
                  },
                );
              }
            );
          },),
      ),
    );
  }
}

