import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nylon/core/function/snack_bar.dart';
import 'package:nylon/core/function/status_request.dart';
import 'package:nylon/features/cart/presentation/screens/widgets/container_cart_product.dart';
import 'package:nylon/features/cart/presentation/controller/controller_cart.dart';
import 'package:nylon/features/orders/presentation/controller/controller_order.dart';
import 'package:nylon/features/payment/presentation/controller/controller_payment.dart';
import 'package:nylon/features/shipping/presentation/controller/controller_shipping.dart';

import '../../../../../core/theme/colors_app.dart';
import '../widgets/button_on_cart.dart';

import '../widgets/row_invoice.dart';

// ignore: must_be_immutable
class OrderConfirmation extends StatelessWidget {
  OrderConfirmation({super.key});
  final ControllerCart _controller = Get.find<ControllerCart>();
  final ControllerPayment _controllerPayment = Get.find();
  final ControllerShipping _controllerShipping = Get.find();
  final ControllerOrder _controllerOrder = Get.find();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: LayoutBuilder(
          builder: (context, boxSize) {
            return GetBuilder<ControllerCart>(builder: (_controller) {
              return _controller.cartModel!.products!.isNotEmpty
                  ? ListView(
                      children: [
                        Container(
                          margin: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 8),
                          child: ListView.separated(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              separatorBuilder: (context, i) => SizedBox(
                                    height: boxSize.maxHeight * 0.01,
                                  ),
                              itemCount:
                                  _controller.cartModel!.products!.length,
                              itemBuilder: (context, i) {
                                return ContainerProductCart(
                                  products: _controller.cartModel!.products![i],
                                  onCart: false,
                                );
                              }),
                        ),
                        SizedBox(
                          height: boxSize.maxHeight * 0.02,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          child: Text(
                            "34".tr,
                            style: Theme.of(context)
                                .textTheme
                                .bodyMedium
                                ?.copyWith(fontSize: 18),
                          ),
                        ),
                        SizedBox(
                          height: boxSize.maxHeight * 0.02,
                        ),
                        Center(
                            child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 12),
                          width: boxSize.maxWidth * 0.90,
                          decoration: BoxDecoration(
                              color: Colors.grey[300],
                              borderRadius: BorderRadius.circular(20)),
                          child: Text(
                            '${_controllerPayment.cAddress.text}'.tr,
                            style: Theme.of(context)
                                .textTheme
                                .bodySmall
                                ?.copyWith(
                                    color: Colors.black,
                                    fontSize: 12,
                                    fontWeight: FontWeight.normal),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        )),
                        SizedBox(
                          height: boxSize.maxHeight * 0.04,
                        ),
                        Row(
                          children: [
                            Text(
                              '170'.tr,
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                            const SizedBox(
                              width: 4,
                            ),
                            Text(
                              _controllerShipping.Shippingtitle,
                              style: Theme.of(context).textTheme.bodySmall,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),

                        SizedBox(
                          height: boxSize.maxHeight * 0.04,
                        ),
                        Row(
                          children: [
                            Text(
                              '169'.tr,
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                            const SizedBox(
                              width: 4,
                            ),
                            Expanded(
                              child: Text(
                                _controllerPayment.titlePayment,
                                style: Theme.of(context).textTheme.bodySmall,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                        if (_controllerPayment.selectCodePayment ==
                            'bank_transfer') ...{
                          SizedBox(
                            height: boxSize.maxHeight * 0.04,
                          ),
                          GetBuilder<ControllerPayment>(
                            builder: (_controllerPayment) {
                              return Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Flexible(
                                    child: Text('177'.tr,
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodySmall,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis),
                                  ),
                                  Stack(
                                    alignment: Alignment.topLeft,
                                    children: [
                                      Container(
                                        height: 95,
                                        width: 75,
                                        decoration: BoxDecoration(
                                            color: Colors.grey[300],
                                            borderRadius:
                                                BorderRadius.circular(6)),
                                        child: _controllerPayment.file != null
                                            ? Image.file(
                                                _controllerPayment.file!,
                                                fit: BoxFit.fill,
                                              )
                                            : Center(
                                                child: InkWell(
                                                    onTap: () async {
                                                      await _controllerPayment
                                                          .addImagesPicker();
                                                    },
                                                    child: Icon(
                                                        Icons.upload_file,
                                                        size: 26,
                                                        color:
                                                            Colors.grey[800]))),
                                      ),
                                      if (_controllerPayment.file != null)
                                        InkWell(
                                            onTap: () async {
                                              if (_controllerPayment.file !=
                                                  null) {
                                                try {
                                                  // تحقق من وجود الملف أولاً قبل محاولة حذفه
                                                  if (await _controllerPayment
                                                      .file!
                                                      .exists()) {
                                                    await _controllerPayment
                                                        .file!
                                                        .delete();
                                                  }
                                                  _controllerPayment.file =
                                                      null; // تعيين الملف إلى null لإخفائه
                                                  _controllerPayment
                                                      .update(); // تحديث واجهة المستخدم
                                                } catch (e) {
                                                  print(
                                                      'Error deleting file: $e');
                                                }
                                              }
                                            },
                                            child: const Icon(
                                              Icons.clear,
                                              size: 16,
                                              color: Colors.black,
                                            )),
                                    ],
                                  )
                                ],
                              );
                            },
                          )
                        },

                        SizedBox(
                          height: boxSize.maxHeight * 0.03,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          child: Text(
                            "42".tr,
                            style: Theme.of(context)
                                .textTheme
                                .bodyMedium
                                ?.copyWith(fontSize: 18),
                          ),
                        ),

                        SizedBox(
                          height: boxSize.maxHeight * 0.04,
                        ),

                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: ListView.separated(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemCount:
                                  _controller.cartModel!.totals!.length ?? 0,
                              separatorBuilder: (context, i) => SizedBox(
                                    height: boxSize.maxHeight * 0.01,
                                  ),
                              itemBuilder: (context, i) {
                                return invoiceRow(
                                    title: _controller
                                        .cartModel!.totals![i].title!,
                                    price: _controller
                                        .cartModel!.totals![i].text!);
                              }),
                          // invoiceRow(title: _controller.cartModel!.totals![0].title!,price: _controller.cartModel!.totals![0].text!),
                          // SizedBox(height: boxSize.maxHeight*0.01,),
                          // invoiceRow(title: _controller.cartModel!.totals![1].title!,price:  _controller.cartModel!.totals![1].text! ),
                          // SizedBox(height: boxSize.maxHeight*0.01,),
                          // invoiceRow(title: _controller.cartModel!.totals![2].title!,price:_controller.cartModel!.totals![2].text!),
                          // SizedBox(height: boxSize.maxHeight*0.01,),
                          // invoiceRow(title: _controller.cartModel!.totals![3].title!,price:_controller.cartModel!.totals![3].text!),
                          // SizedBox(height: boxSize.maxHeight*0.01,),
                        ),

                        SizedBox(
                          height: boxSize.maxHeight * 0.03,
                        ),
                        GetBuilder<ControllerOrder>(
                            builder: (_controllerOrder) {
                          return _controllerOrder.statusRequestSendOrder ==
                                  StatusRequest.loading
                              ? Center(
                                  child: CircularProgressIndicator(
                                    color: AppColors.primaryColor,
                                  ),
                                )
                              : ButtonOnCart(
                                  width: boxSize.maxWidth * 0.80,
                                  label: '36'.tr,
                                  onTap: () async {
                                    if (_controllerPayment.selectCodePayment ==
                                            'bank_transfer' &&
                                        _controllerPayment.file == null) {
                                      showSnackBar('186'.tr);
                                    } else {
                                      await _controllerOrder.sendOrder();
                                      if (_controllerOrder
                                              .statusRequestSendOrder ==
                                          StatusRequest.success) {
                                        _controller.plusIndexScreensCart();
                                        // _controller.getCart();
                                      } else {
                                        print('errrrrrrrOR uiiiiiiiiiii');
                                      }
                                    }
                                  });
                        }),

                        SizedBox(
                          height: boxSize.maxHeight * 0.03,
                        ),
                        //
                      ],
                    )
                  : Center(
                      child: Text(
                        '149'.tr,
                        style: Theme.of(context).textTheme.bodyMedium,
                        textAlign: TextAlign.center,
                      ),
                    );
            });
          },
        ),
      ),
    );
  }
}
