import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../../../core/theme/colors_app.dart';

Widget invoiceRow({required String title, required String price}) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(
        title,
        style: Theme.of(Get.context!).textTheme.bodySmall?.copyWith(),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      Text(
        price,
        style: Theme.of(Get.context!).textTheme.bodySmall?.copyWith(
              color: AppColors.greyColor,
            ),
      ),
    ],
  );
}
