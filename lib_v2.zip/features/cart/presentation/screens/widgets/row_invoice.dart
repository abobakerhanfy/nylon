import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../../../../core/theme/colors_app.dart';

/// ويدجت لصف سطر فاتورة بعنوان وسعر
Widget invoiceRow({
  required String title,
  required Widget priceWidget,
}) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(
        title,
        style: Theme.of(Get.context!).textTheme.bodySmall,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      priceWidget,
    ],
  );
}

/// ويدجت مساعدة لعرض نص السعر بجانب رمز الريال (صورة)
Widget textWithRiyal(String value, {TextStyle? style, double iconHeight = 14}) {
  return Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Text(value, style: style),
      const SizedBox(width: 4),
      Image.asset("images/riyalsymbol_compressed.png", height: iconHeight),
    ],
  );
}
