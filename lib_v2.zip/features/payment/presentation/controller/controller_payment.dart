import 'dart:io';
import 'dart:convert'; // Added for jsonDecode
import 'package:nylon/core/url/url_api.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:nylon/features/payment/presentation/screens/payment_webview_screen.dart';

import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:nylon/core/function/snack_bar.dart';
import 'package:nylon/core/function/status_request.dart';
import 'package:nylon/core/widgets/login/dialog.dart';
import 'package:nylon/core/widgets/primary_button.dart';
import 'package:nylon/features/orders/presentation/controller/controller_order.dart';
import 'package:nylon/features/payment/data/data_sources/payment_data_source.dart';
import 'package:nylon/features/payment/data/models/address_model.dart';
import 'package:nylon/features/payment/data/models/model_myfatoorah.dart';
import 'package:nylon/features/payment/data/models/test_zone.dart';
import 'package:nylon/features/payment/data/models/model_tamarapay.dart';
import 'package:nylon/features/payment/data/models/payment_model.dart';
import 'package:nylon/features/payment/data/models/select_patment.dart';
import 'package:nylon/features/payment/data/models/zone_id_city.dart';
import 'package:nylon/features/shipping/presentation/controller/controller_shipping.dart';
import 'package:nylon/features/cart/presentation/controller/controller_cart.dart';
import 'package:nylon/features/profile/data/models/address_list_model.dart';
import 'package:nylon/features/profile/data/data_sources/profile_data_source.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:nylon/core/services/services.dart';

abstract class PaymentController extends GetxController {
  Future addAddressPayment();
  Future getPayment();
  Future selectPayment({required String paymentCode});
  void selectCode({required String code, required String title});
  Future getZoneId();
  Future addIamgeBankTr();
  Future confirmBankTransfer();
  Future paymentMyFatoorah();
  Future paymentTamaraPay();
  Future checkTamaraPaymentStatus();
  Future checkPayment();
  Future<void> fetchUserAddresses();
  Future<void> selectAddress(String addressId);
  Future paymentMyFatoorahBlance();
  Future paymentTabby();
}

class ControllerPayment extends PaymentController {
  final PaymentDataSourceImpl _paymentDataSourceImpl =
      PaymentDataSourceImpl(Get.find());
  final MyServices _myServices = Get.find();

  final ProfileDataSourceImpl _profileDataSourceImpl =
      ProfileDataSourceImpl(Get.find());
  final ControllerShipping _controllerShipping = Get.put(ControllerShipping());
  GlobalKey<FormState> formAddAddress = GlobalKey<FormState>();
  GlobalKey<FormState> formMyFatoorahCard = GlobalKey<FormState>();
  PaymentModel? paymentModel;
  List<PaymentsData> paymentsDataList = [];
  String selectCodePayment = '';
  String titlePayment = '';
  StatusRequest? statusRequestAddAddress,
      statusRequestGetZone,
      statusRequestsendCode,
      statusRequestsendCodeFuser,
      statusRequestGetPayment,
      statusRequestSelectPayment,
      statusRequestAddCustomer,
      statusRequestpMyFatoorah,
      statusRequestTamaraPay,
      statusRequestCheckTamara,
      statusRequestConfBank,
      statusRequestAddImage;

  AddressModel? allAddress;
  ModelMyFatoorah? modelMyFatoorah;
  TamarapayModel? tamarapayModel;
  final TextEditingController cFirstName = TextEditingController();
  final TextEditingController cLastName = TextEditingController();
  final TextEditingController cAddress = TextEditingController();
  final TextEditingController cCitys = TextEditingController();
  final TextEditingController cCountryId = TextEditingController();
  final TextEditingController cZoneId = TextEditingController();
  final TextEditingController cPhone = TextEditingController();
  final TextEditingController cEmail = TextEditingController();
  var cCardName = TextEditingController();
  var cCardnumber = TextEditingController();
  var cExpirationDate = TextEditingController();
  var cSecurityCode = TextEditingController();
  bool isAddressConfirmed = false;
  List<Zone> zoneId = [];
  File? file;
  final _imagePicker = ImagePicker();
  bool isReturningFromPayment = false;
  bool checkPaymentValue = false;

  List<Address> userAddresses = [];
  String? selectedAddressId;
  StatusRequest? statusRequestGetAddresses;

  @override
  void onInit() {
    getPayment();
    fetchUserAddresses();
    getZoneId();

    super.onInit();
  }

  @override
  Future addAddressPayment() async {
    var validator = formAddAddress.currentState;
    if (validator!.validate()) {
      statusRequestAddAddress = StatusRequest.loading;
      update();
      Map<String, dynamic> data = {
        'firstname': cFirstName.text,
        'lastname': cLastName.text,
        'address_1': cAddress.text,
        'city': cCitys.text,
        'country_id': cCountryId.text.isNotEmpty ? cCountryId.text : '0',
        'zone_id': cZoneId.text.isNotEmpty ? cZoneId.text : '0',
      };

      var response = await _paymentDataSourceImpl.addAddressPayment(data: data);
      await _controllerShipping.addAddressShipping(data: data);
      return response.fold((failure) {
        statusRequestAddAddress = failure;
        print("Error adding payment address: $failure");
        showSnackBar("187".tr);
        update();
      }, (data) {
        if (data.containsKey("error")) {
          var errorData = data["error"];
          if (errorData is Map && errorData.isNotEmpty) {
            showSnackBar('${errorData.values.first}');
            statusRequestAddAddress = StatusRequest.failure;
          } else {
            showSnackBar(data["error"].toString());
            statusRequestAddAddress = StatusRequest.failure;
          }
          update();
        } else if (data.containsKey("success")) {
          statusRequestAddAddress = StatusRequest.success;
          getPayment();
          _controllerShipping.getShippingMethods();
          fetchUserAddresses();
          print("Successfully added address: $data");
          cFirstName.clear();
          cLastName.clear();
          cAddress.clear();
          cCitys.clear();
          cCountryId.clear();
          cZoneId.clear();
          update();
          // Corrected showSnackBar call: removed getXSnackBar argument
          showSnackBar("188".tr);
        }
      });
    }
  }

  @override
  Future getPayment() async {
    statusRequestGetPayment = StatusRequest.loading;
    update();

    var response = await _paymentDataSourceImpl.getPayment();

    return response.fold((failure) {
      statusRequestGetPayment = failure;
      print('Error getting payment methods: $failure');
      update();
    }, (data) async {
      if (data.containsKey("error")) {
        statusRequestGetPayment = StatusRequest.badRequest;
        print('Error response getting payment methods: ${data["error"]}');
        update();
      } else {
        try {
          paymentModel = PaymentModel.fromJson(data as Map<String, dynamic>);
          paymentsDataList =
              await paymentModel!.paymentMethods!.toPaymentsDataList();

          print('✅ Fetched ${paymentsDataList.length} payment methods.');
          await checkLocalImageAssets(paymentsDataList);

          statusRequestGetPayment = StatusRequest.success;
        } catch (e) {
          print('❌ Error parsing payment methods: $e');
          statusRequestGetPayment = StatusRequest.serverFailure;
        }
        update();
      }
    });
  }

  void openPaymentWebView(
      {required String gateway, required String url}) async {
    final orderId = selectPaymentModel?.orderId;

    if (orderId != null) {
      print("✅ Order iD Not Heere $orderId");

      await checkAndUpdateOrderStatus(orderId.toString());
    }
    print(
        "✅ Reached openPaymentWebView with gateway: $gateway & Order Id $orderId");
    print("✅ openPaymentWebView called");
    print("🟢 gateway: $gateway");
    print("🔗 url: $url");
    print("📦 Order ID: ${selectPaymentModel?.orderId}");
    switch (gateway) {
      case 'tamarapay':
        print("🔗 Trying to open tamara: $url");

        String modifiedUrl = url.contains("?")
            ? "$url&order_id=${selectPaymentModel?.orderId?.toString() ?? ''}&is_app=1"
            : "$url?order_id=${selectPaymentModel?.orderId?.toString() ?? ''}&is_app=1";

        Get.to(() => PaymentWebViewScreen(
              url: modifiedUrl,
              orderId: selectPaymentModel?.orderId?.toString() ?? '',
              successKeyword: 'tamarapay/success',
              failKeyword: 'tamarapay/failure',
            ));

        break;

      case 'myfatoorah_pg':
        print("🔗 Trying to open myfatoorah_pg: $url");

        String modifiedUrl = url.contains("?")
            ? "$url&order_id=${selectPaymentModel?.orderId?.toString() ?? ''}&is_app=1"
            : "$url?order_id=${selectPaymentModel?.orderId?.toString() ?? ''}&is_app=1";

        Get.to(() => PaymentWebViewScreen(
              url: modifiedUrl,
              orderId: selectPaymentModel?.orderId?.toString() ?? '',

              successKeyword: 'success', // أو حسب ما يظهر في رابط النجاح
              failKeyword: 'fail', // أو 'error' أو 'cancel'
            ));
        break;

      case 'tabby_cc_installments':
        String modifiedUrl =
            url.contains("?") ? "$url&is_app=1" : "$url?is_app=1";

        Get.to(() => PaymentWebViewScreen(
              url: modifiedUrl,
              orderId: selectPaymentModel?.orderId?.toString() ?? '',
              successKeyword: 'extension/payment/tabby/confirm',
              failKeyword: 'checkout/checkout',
            ));
        break;
      default:
        Get.snackbar("خطأ", "بوابة الدفع غير معروفة");
    }
  }

  Future<void> checkAndUpdateOrderStatus(String orderId) async {
    final url = "${AppApi.checkOrderBuyOrNo}$orderId";

    try {
      final response = await http.get(Uri.parse(url));

      // 🔍 تحقق إن الاستجابة فعلاً JSON
      final contentType = response.headers['content-type'] ?? '';
      if (!contentType.contains('application/json')) {
        print("❌ الاستجابة ليست JSON: ${response.body}");
        return; // توقف بدون كراش
      }

      final json = jsonDecode(response.body);

      if (json["success"] == false) {
        print("🚨 الطلب $orderId حالته مفقود، سيتم تحديثه إلى معلق");

        final updateUrl = Uri.parse("${AppApi.checkOrderBuyOrNo}$orderId");
        final updateResponse = await http.post(updateUrl, body: {
          "status": "معلق",
        });

        if (updateResponse.statusCode == 200) {
          print("✅ تم تحديث الطلب إلى معلق بنجاح");
        } else {
          print("❌ فشل في تحديث حالة الطلب: ${updateResponse.body}");
        }
      } else {
        print("✅ الطلب $orderId حالته بالفعل: ${json['status']}");
      }
    } catch (e) {
      print("❌ خطأ أثناء التحقق أو التحديث: $e");
    }
  }

  /// ✅ دالة لفحص الصور في مجلد images/
  Future<void> checkLocalImageAssets(List<PaymentsData> list) async {
    print('🔍 Checking image asset files...');
    for (var payment in list) {
      print('--- ${payment.code} ---');
      if (payment.separatedImages != null &&
          payment.separatedImages!.isNotEmpty) {
        for (var img in payment.separatedImages!) {
          final fileName = img.split('/').last;
          final localPath = 'images/$fileName';

          try {
            await rootBundle.load(localPath);
            print('✅ Found: $localPath');
          } catch (e) {
            print('⚠️ Missing: $localPath');
          }
        }
      } else {
        print('❗ No images for ${payment.code}');
      }
    }
  }

  SelectPaymentModel? selectPaymentModel;
  @override
  Future selectPayment({required String paymentCode}) async {
    statusRequestSelectPayment = StatusRequest.loading;
    update();

    var response =
        await _paymentDataSourceImpl.selectPayment(paymentCode: paymentCode);

    return response.fold(
      (failure) {
        statusRequestSelectPayment = failure;
        print('Error selecting payment: $failure');
        update();
      },
      (data) async {
        // ✅ خليها async هنا
        if (data.containsKey("error")) {
          showSnackBar('${data["error"]}');
          statusRequestSelectPayment = StatusRequest.failure;
          print('Error response selecting payment: ${data["error"]}');
          update();
        } else if (data.containsKey("success")) {
          try {
            // 🟢 امسح بيانات الطلب القديمة
            await _myServices.sharedPreferences.remove("order_id");
            await _myServices.sharedPreferences.remove("order_status");

            selectPaymentModel =
                SelectPaymentModel.fromJson(data as Map<String, dynamic>);
            print(
                'Selected payment successfully. Order ID: ${selectPaymentModel!.orderId}');
            statusRequestSelectPayment = StatusRequest.success;

            Get.snackbar(
              '211'.tr, // النص المترجم
              '',
              snackPosition: SnackPosition.BOTTOM,
              duration: Duration(seconds: 1),
              showProgressIndicator: true,
            );

            // 🟢 تأخير بعد النجاح
            await Future.delayed(Duration(milliseconds: 700));
            getPayment();
          } catch (e) {
            print('Error parsing select payment response: $e');
            statusRequestSelectPayment = StatusRequest.serverFailure;
          }
          update();
        }
      },
    );
  }

  Function(bool?)? onChanged(value) {
    isAddressConfirmed = value ?? false;
    update();
    return null;
  }

  Future addImagesPicker() async {
    try {
      var imagePath = await _imagePicker.pickImage(
          source: ImageSource.gallery, maxWidth: 250, imageQuality: 50);
      if (imagePath != null) {
        file = File(imagePath.path);
        print('Image picked: ${file!.path}');
        update();
      }
    } catch (e) {
      print('Error picking image: $e');
    }
  }

  @override
  void selectCode({required String code, required String title}) async {
    // حتى لو اختار نفس الكود، نحدث السيرفر والفاتورة
    selectCodePayment = code;
    titlePayment = title;
    update();

    print('Selected payment code: $selectCodePayment');

    try {
      await Get.find<ControllerOrder>().sendPaymentMethod(paymentMethod: code);
      await Get.find<ControllerCart>().getCart();
      print('✅ Payment method selected => Code: $code | Title: $title');
    } catch (e) {
      print('❌ Error updating payment method or fetching cart: $e');
    }
  }

  Future<void> fetchZones() async {
    try {
      final response = await http.get(Uri.parse(AppApi.getZoneUrl));
      if (response.statusCode == 200) {
        List<dynamic> decodedData = jsonDecode(response.body);
        // Ensure correct parsing if Zone.fromJson expects Map<String, dynamic>
        zoneId = decodedData
            .whereType<Map<String, dynamic>>()
            .map((zoneData) => Zone.fromJson(zoneData))
            .toList();
        print('Fetched ${zoneId.length} zones.');
        update();
      } else {
        throw Exception('Failed to load zones: ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching zones: $e');
    }
  }

  @override
  Future getZoneId() async {
    print('✅ Loading zones from test_zone.dart...');
    statusRequestGetZone = StatusRequest.loading;
    update();

    try {
      zoneId = test.map((json) => Zone.fromJson(json)).toList();

      print('✅ Loaded ${zoneId.length} zones from local test data.');
      statusRequestGetZone = StatusRequest.success;
      update();
    } catch (e) {
      print('❌ Error loading zones from test_zone.dart: $e');
      statusRequestGetZone = StatusRequest.failure;
      update();
    }
  }

  @override
  Future addIamgeBankTr() async {
    if (selectCodePayment == 'bank_transfer' &&
        file != null &&
        file!.path.isNotEmpty) {
      statusRequestAddImage = StatusRequest.loading;
      update();
      var response =
          await _paymentDataSourceImpl.addImageBankTrans(file: file!);
      return response.fold((failure) {
        statusRequestAddImage = failure;
        print('Error uploading bank transfer image: $failure');
        update();
      }, (data) {
        if (data.containsKey("success")) {
          statusRequestAddImage = StatusRequest.success;
          print("Bank transfer image uploaded successfully: $data");
          update();
        } else {
          statusRequestAddImage = StatusRequest.failure;
          print(
              "Failed to upload bank transfer image: ${data['error'] ?? 'Unknown error'}");
          newCustomDialog(
              body: SizedBox(
                height: 40,
                child: PrimaryButton(
                  label: '100'.tr,
                  onTap: () {
                    Get.back();
                  },
                ),
              ),
              title: "180".tr,
              dialogType: DialogType.error);
          update();
        }
      });
    } else {
      print(
          'Cannot upload image: Payment method is not bank transfer or file is missing.');
      if (selectCodePayment != 'bank_transfer') showSnackBar("181".tr);
      if (file == null || file!.path.isEmpty) showSnackBar("182".tr);
    }
  }

  @override
  Future confirmBankTransfer() async {
    statusRequestConfBank = StatusRequest.loading;
    update();
    var response = await _paymentDataSourceImpl.confirmBankTransfer();
    response.fold((failure) {
      statusRequestConfBank = failure;
      print("Error confirming bank transfer: $failure");
      update();
    }, (data) {
      statusRequestConfBank = StatusRequest.success;
      print("Bank transfer confirmed: $data");
      update();
    });
  }

  @override
  Future paymentTamaraPay() async {
    final orderId = selectPaymentModel?.orderId;

    if (orderId == null) {
      showSnackBar("لا يمكن تنفيذ الدفع بدون رقم الطلب");
      statusRequestTamaraPay = StatusRequest.failure;
      update();
      return;
    }

    statusRequestTamaraPay = StatusRequest.loading;
    update();

    var response = await _paymentDataSourceImpl.paymentTamaraPay(data: {
      'order_id': orderId.toString(), // ✅ الحل
    });

    return response.fold((failure) {
      statusRequestTamaraPay = StatusRequest.failure;
      print('Error initiating Tamara Pay: $failure');
      update();
    }, (data) async {
      if (data.isNotEmpty) {
        try {
          tamarapayModel =
              TamarapayModel.fromJson(data as Map<String, dynamic>);
          final redirectUrl = tamarapayModel?.checkoutData?.checkoutRedirectUrl;

          if (redirectUrl != null) {
            print('Tamara Pay redirect URL: $redirectUrl');
            isReturningFromPayment = true;
            statusRequestTamaraPay = StatusRequest.success;
            update();

            // ✅ فتح WebView داخلي للدفع
            openPaymentWebView(
              gateway: 'tamarapay',
              url: redirectUrl,
            );
          } else {
            statusRequestTamaraPay = StatusRequest.failure;
            print("Tamara Pay error: Missing redirect URL. Response: $data");
            showSnackBar("184".tr); // فشل في إنشاء الطلب
            update();
          }
        } catch (e) {
          statusRequestTamaraPay = StatusRequest.failure;
          print("Error parsing Tamara Pay response: $e");
          showSnackBar("185".tr); // خطأ في البيانات
          update();
        }
      } else {
        statusRequestTamaraPay = StatusRequest.failure;
        print("Tamara Pay error: Empty response data.");
        showSnackBar("184".tr); // البيانات فارغة
        update();
      }
    });
  }

  @override
  Future checkTamaraPaymentStatus() async {
    if (isReturningFromPayment == true &&
        tamarapayModel?.checkoutData?.tamaraOrderId != null) {
      print(
          "Checking Tamara payment status for order ID: ${tamarapayModel!.checkoutData!.tamaraOrderId}");
      statusRequestCheckTamara = StatusRequest.loading;
      update();
      var response = await _paymentDataSourceImpl.checkTamaraPaymentStatus(
          tamaraOrderId: tamarapayModel!.checkoutData!.tamaraOrderId!);
      return response.fold((failure) {
        statusRequestCheckTamara = failure;
        print('Error checking Tamara payment status: $failure');
        update();
      }, (data) async {
        if (data.containsKey("success") && data["success"] == true) {
          statusRequestCheckTamara = StatusRequest.success;
          print("Tamara payment successful: $data");
          update();
          try {
            ControllerOrder _controllerOrder = Get.find();
            await _controllerOrder.sendOrder();
            print("Order sent after successful Tamara payment.");
          } catch (e) {
            print("Error finding or calling ControllerOrder.sendOrder: $e");
          }
          isReturningFromPayment = false;
          update();
        } else {
          statusRequestCheckTamara = StatusRequest.failure;
          print("Tamara payment check failed or payment not complete: $data");
          newCustomDialog(
              body: SizedBox(
                height: 40,
                child: PrimaryButton(
                  label: '100'.tr,
                  onTap: () {
                    Get.back();
                  },
                ),
              ),
              title: "186".tr,
              dialogType: DialogType.error);
          isReturningFromPayment = false;
          update();
        }
      });
    } else {
      print(
          "Skipping Tamara payment check: Not returning from payment or missing order ID.");
    }
  }

  @override
  Future<String?> paymentMyFatoorah() async {
    final orderId = selectPaymentModel?.orderId;
    if (orderId == null) {
      showSnackBar("لا يمكن تنفيذ الدفع بدون رقم الطلب");
      statusRequestpMyFatoorah = StatusRequest.failure;
      update();
      return null;
    }

    statusRequestpMyFatoorah = StatusRequest.loading;
    update();

    final response = await _paymentDataSourceImpl.paymentMyFatoorah(
      data: {"order_id": orderId},
    );

    return await response.fold(
      (failure) async {
        statusRequestpMyFatoorah = StatusRequest.failure;
        print('❌ Error initiating MyFatoorah payment: $failure');
        update();
        return null;
      },
      (data) async {
        print('📦 MyFatoorah response: $data');
        print("📊 Type of data: ${data.runtimeType}");

        try {
          final Map<String, dynamic> parsedData = data.cast<String, dynamic>();

          if (parsedData['success'] == true &&
              parsedData['invoiceURL'] != null) {
            modelMyFatoorah = ModelMyFatoorah.fromJson(parsedData);
            final paymentUrl = modelMyFatoorah?.paymentUrl;

            if (paymentUrl != null && paymentUrl.startsWith("http")) {
              checkPaymentValue = true;
              update();
              print('🔗 MyFatoorah Payment URL: $paymentUrl');

              openPaymentWebView(
                gateway: 'myfatoorah_pg',
                url: paymentUrl,
              );

              return paymentUrl;
            } else {
              throw Exception("رابط الدفع غير متوفر");
            }
          } else {
            throw Exception("الاستجابة غير مكتملة أو فاشلة");
          }
        } catch (e, stack) {
          statusRequestpMyFatoorah = StatusRequest.failure;
          print("❌ Exception: $e");
          print("📍 StackTrace: $stack");
          showSnackBar("فشل في معالجة الدفع");
          update();
          return null;
        }
      },
    );
  }

  @override
  Future checkPayment() async {
    if (selectPaymentModel?.orderId == null) {
      print("❌ لا يمكن تنفيذ الدفع بدون رقم الطلب");
      showSnackBar("فشل تنفيذ الدفع، لا يوجد رقم طلب.");
      return;
    }

    print(
        "Checking payment status for order ID: ${selectPaymentModel!.orderId}");
    update();
    var response = await _paymentDataSourceImpl.checkPayment(
        orderId: selectPaymentModel!.orderId!);
    response.fold((failure) {
      print("Error checking payment status: $failure");
      update();
    }, (data) {
      print("Payment status check response: $data");
      if (data.containsKey("success") && data["success"] == true) {
        print("Payment confirmed via checkPayment.");
      } else {
        print("Payment not confirmed via checkPayment.");
      }
      update();
    });
  }

  @override
  Future<void> fetchUserAddresses() async {
    statusRequestGetAddresses = StatusRequest.loading;
    update();
    print("Fetching user addresses...");
    var response = await _profileDataSourceImpl.getAddresses();
    response.fold(
      (failure) {
        statusRequestGetAddresses = failure;
        print("Failed to fetch addresses: $failure");
        userAddresses = [];
        update();
      },
      (addresses) {
        userAddresses = addresses;
        selectedAddressId = userAddresses
            .firstWhereOrNull((addr) => addr.defaultAddress == true)
            ?.addressId;
        if (selectedAddressId == null && userAddresses.isNotEmpty) {
          selectedAddressId = userAddresses.first.addressId;
          print(
              "No default address found, selecting first address ID: $selectedAddressId");
          if (selectedAddressId != null) {
            print(
                "Auto-selected address. Reloading cart and shipping methods...");
            Get.find<ControllerCart>().getCart();
            _controllerShipping.getShippingMethods();
          }
        }
        statusRequestGetAddresses = StatusRequest.success;
        print(
            "Fetched ${userAddresses.length} addresses. Selected ID: $selectedAddressId");
        update();
      },
    );
  }

  @override
  Future<void> selectAddress(String addressId) async {
    if (selectedAddressId == addressId) {
      print("Address ID $addressId already selected.");
      return;
    }
    print("Selecting address ID: $addressId");
    selectedAddressId = addressId;
    print("Address selected locally. Reloading cart and shipping methods...");
    Get.find<ControllerCart>().getCart();
    _controllerShipping.getShippingMethods();
    update();
  }

  @override
  Future paymentMyFatoorahBlance() async {
    print(
        "Placeholder: paymentMyFatoorahBlance called. Implement actual logic.");
    await Future.delayed(Duration(seconds: 1));
    showSnackBar("Functionality not implemented yet.");
  }

  Future<void> paymentTabby() async {
    final webUrl = selectPaymentModel?.webUrl;

    if (webUrl != null && webUrl.startsWith("http")) {
      print("✅ فتح رابط Tabby: $webUrl");

      openPaymentWebView(
        gateway: 'tabby_cc_installments',
        url: webUrl,
      );
    } else {
      print("❌ رابط الدفع غير موجود أو غير صحيح");
      showSnackBar("رابط الدفع غير متاح حالياً");
    }
  }
}
