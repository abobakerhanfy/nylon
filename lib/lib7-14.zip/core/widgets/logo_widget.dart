import 'package:flutter/cupertino.dart';
import 'package:nylon/core/static/static_images.dart';

Widget logoWidget (){
  return Image.asset(StaticAppImages.imageLogo);
}