List  test =[
    {
        "zone_id": "147",
        "country_id": "4",
        "name": "أملج",
        "name_ar": "أملج",
        "code": "أملج",
        "status": "1"
    },
    {
        "zone_id": "100",
        "country_id": "4",
        "name": "ابا الورود",
        "name_ar": "ابا الورود",
        "code": "ابا الورود",
        "status": "1"
    },
    {
        "zone_id": "117",
        "country_id": "4",
        "name": "ابانات",
        "name_ar": "ابانات",
        "code": "ابانات",
        "status": "1"
    },
    {
        "zone_id": "151",
        "country_id": "4",
        "name": "ابها",
        "name_ar": "ابها",
        "code": "ابها",
        "status": "1"
    },
    {
        "zone_id": "181",
        "country_id": "4",
        "name": "ابو عريش",
        "name_ar": "ابو عريش",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "129",
        "country_id": "4",
        "name": "احد رفيدة",
        "name_ar": "احد رفيدة",
        "code": "احد رفيدة",
        "status": "1"
    },
    {
        "zone_id": "182",
        "country_id": "4",
        "name": "احد مسارحة",
        "name_ar": "احد مسارحة",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "56",
        "country_id": "4",
        "name": "اشيقر",
        "name_ar": "اشيقر",
        "code": "اشيقر",
        "status": "1"
    },
    {
        "zone_id": "24",
        "country_id": "4",
        "name": "الأحساء",
        "name_ar": "الأحساء",
        "code": "AQ",
        "status": "1"
    },
    {
        "zone_id": "130",
        "country_id": "4",
        "name": "الأفلاج",
        "name_ar": "الأفلاج",
        "code": "الأفلاج",
        "status": "1"
    },
    {
        "zone_id": "95",
        "country_id": "4",
        "name": "الاسياح",
        "name_ar": "الاسياح",
        "code": "الاسياح",
        "status": "1"
    },
    {
        "zone_id": "18",
        "country_id": "4",
        "name": "الباحه",
        "name_ar": "الباحه",
        "code": "BH",
        "status": "1"
    },
    {
        "zone_id": "106",
        "country_id": "4",
        "name": "البدائع",
        "name_ar": "البدائع",
        "code": "البدائع",
        "status": "1"
    },
    {
        "zone_id": "172",
        "country_id": "4",
        "name": "البدع",
        "name_ar": "البدع",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "109",
        "country_id": "4",
        "name": "البصر",
        "name_ar": "البصر",
        "code": "البصر",
        "status": "1"
    },
    {
        "zone_id": "98",
        "country_id": "4",
        "name": "البطين",
        "name_ar": "البطين",
        "code": "البطين",
        "status": "1"
    },
    {
        "zone_id": "103",
        "country_id": "4",
        "name": "البكيرية",
        "name_ar": "البكيرية",
        "code": "البكيرية",
        "status": "1"
    },
    {
        "zone_id": "101",
        "country_id": "4",
        "name": "التنومة",
        "name_ar": "التنومة",
        "code": "التنومة",
        "status": "1"
    },
    {
        "zone_id": "42",
        "country_id": "4",
        "name": "الثقبة",
        "name_ar": "الثقبة",
        "code": "الثقبة",
        "status": "1"
    },
    {
        "zone_id": "40",
        "country_id": "4",
        "name": "الجبيل",
        "name_ar": "الجبيل",
        "code": "الجبيل",
        "status": "1"
    },
    {
        "zone_id": "62",
        "country_id": "4",
        "name": "الجبيلة",
        "name_ar": "الجبيلة",
        "code": "الجبيلة",
        "status": "1"
    },
    {
        "zone_id": "177",
        "country_id": "4",
        "name": "الجعرانه",
        "name_ar": "الجعرانه",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "146",
        "country_id": "4",
        "name": "الجموم",
        "name_ar": "الجموم",
        "code": "الجموم",
        "status": "1"
    },
    {
        "zone_id": "20",
        "country_id": "4",
        "name": "الجوف",
        "name_ar": "الجوف",
        "code": "JF",
        "status": "1"
    },
    {
        "zone_id": "81",
        "country_id": "4",
        "name": "الحائر",
        "name_ar": "الحائر",
        "code": "الحائر",
        "status": "1"
    },
    {
        "zone_id": "169",
        "country_id": "4",
        "name": "الحائط",
        "name_ar": "الحائط",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "19",
        "country_id": "4",
        "name": "الحدود الشمالية",
        "name_ar": "الحدود الشمالية",
        "code": "HS",
        "status": "1"
    },
    {
        "zone_id": "168",
        "country_id": "4",
        "name": "الحديثه",
        "name_ar": "الحديثه",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "71",
        "country_id": "4",
        "name": "الحريق",
        "name_ar": "الحريق",
        "code": "الحريق",
        "status": "1"
    },
    {
        "zone_id": "64",
        "country_id": "4",
        "name": "الحزم",
        "name_ar": "الحزم",
        "code": "الحزم",
        "status": "1"
    },
    {
        "zone_id": "75",
        "country_id": "4",
        "name": "الحسى",
        "name_ar": "الحسى",
        "code": "الحسى",
        "status": "1"
    },
    {
        "zone_id": "72",
        "country_id": "4",
        "name": "الحلوه",
        "name_ar": "الحلوه",
        "code": "الحلوه",
        "status": "1"
    },
    {
        "zone_id": "143",
        "country_id": "4",
        "name": "الحناكية",
        "name_ar": "الحناكية",
        "code": "الحناكية",
        "status": "1"
    },
    {
        "zone_id": "120",
        "country_id": "4",
        "name": "الحوية",
        "name_ar": "الحوية",
        "code": "الحوية",
        "status": "1"
    },
    {
        "zone_id": "44",
        "country_id": "4",
        "name": "الخبر",
        "name_ar": "الخبر",
        "code": "الخبر",
        "status": "1"
    },
    {
        "zone_id": "108",
        "country_id": "4",
        "name": "الخبراء",
        "name_ar": "الخبراء",
        "code": "الخبراء",
        "status": "1"
    },
    {
        "zone_id": "31",
        "country_id": "4",
        "name": "الخرج",
        "name_ar": "الخرج",
        "code": "11942",
        "status": "1"
    },
    {
        "zone_id": "208",
        "country_id": "4",
        "name": "الخرمة",
        "name_ar": "الخرمة",
        "code": "الخرمة",
        "status": "1"
    },
    {
        "zone_id": "134",
        "country_id": "4",
        "name": "الخفجي",
        "name_ar": "الخفجي",
        "code": "الخفجي",
        "status": "1"
    },
    {
        "zone_id": "204",
        "country_id": "4",
        "name": "الدائر",
        "name_ar": "الدائر",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "171",
        "country_id": "4",
        "name": "الدرب",
        "name_ar": "الدرب",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "68",
        "country_id": "4",
        "name": "الدلم",
        "name_ar": "الدلم",
        "code": "الدلم",
        "status": "1"
    },
    {
        "zone_id": "115",
        "country_id": "4",
        "name": "الدليمية",
        "name_ar": "الدليمية",
        "code": "الدليمية",
        "status": "1"
    },
    {
        "zone_id": "35",
        "country_id": "4",
        "name": "الدمام",
        "name_ar": "الدمام",
        "code": "Dammam",
        "status": "1"
    },
    {
        "zone_id": "125",
        "country_id": "4",
        "name": "الدوادمي",
        "name_ar": "الدوادمي",
        "code": "الدوادمي",
        "status": "1"
    },
    {
        "zone_id": "104",
        "country_id": "4",
        "name": "الرس",
        "name_ar": "الرس",
        "code": "الرس",
        "status": "1"
    },
    {
        "zone_id": "54",
        "country_id": "4",
        "name": "الرويضه",
        "name_ar": "الرويضه",
        "code": "الرويضه",
        "status": "1"
    },
    {
        "zone_id": "23",
        "country_id": "4",
        "name": "الرياض",
        "name_ar": "الرياض",
        "code": "RD",
        "status": "1"
    },
    {
        "zone_id": "46",
        "country_id": "4",
        "name": "الزلفي",
        "name_ar": "الزلفي",
        "code": "الزلفي",
        "status": "1"
    },
    {
        "zone_id": "170",
        "country_id": "4",
        "name": "السليل",
        "name_ar": "السليل",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "96",
        "country_id": "4",
        "name": "الشماسية",
        "name_ar": "الشماسية",
        "code": "الشماسية",
        "status": "1"
    },
    {
        "zone_id": "203",
        "country_id": "4",
        "name": "الشملي",
        "name_ar": "الشملي",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "118",
        "country_id": "4",
        "name": "الشيحية",
        "name_ar": "الشيحية",
        "code": "الشيحية",
        "status": "1"
    },
    {
        "zone_id": "65",
        "country_id": "4",
        "name": "الضبيعة",
        "name_ar": "الضبيعة",
        "code": "الضبيعة",
        "status": "1"
    },
    {
        "zone_id": "38",
        "country_id": "4",
        "name": "الطائف",
        "name_ar": "الطائف",
        "code": "TA",
        "status": "1"
    },
    {
        "zone_id": "116",
        "country_id": "4",
        "name": "الظاهرية",
        "name_ar": "الظاهرية",
        "code": "الظاهرية",
        "status": "1"
    },
    {
        "zone_id": "123",
        "country_id": "4",
        "name": "الظهران",
        "name_ar": "الظهران",
        "code": "الظهران",
        "status": "1"
    },
    {
        "zone_id": "199",
        "country_id": "4",
        "name": "العثمانية",
        "name_ar": "العثمانية",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "142",
        "country_id": "4",
        "name": "العلا",
        "name_ar": "العلا",
        "code": "العلا",
        "status": "1"
    },
    {
        "zone_id": "114",
        "country_id": "4",
        "name": "العمار",
        "name_ar": "العمار",
        "code": "العمار",
        "status": "1"
    },
    {
        "zone_id": "67",
        "country_id": "4",
        "name": "العمجية",
        "name_ar": "العمجية",
        "code": "العمجية",
        "status": "1"
    },
    {
        "zone_id": "209",
        "country_id": "4",
        "name": "العيدابي",
        "name_ar": "العيدابي",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "197",
        "country_id": "4",
        "name": "العيون",
        "name_ar": "العيون",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "61",
        "country_id": "4",
        "name": "العيينة",
        "name_ar": "العيينة",
        "code": "العيينة",
        "status": "1"
    },
    {
        "zone_id": "133",
        "country_id": "4",
        "name": "الغاط",
        "name_ar": "الغاط",
        "code": "الغاط",
        "status": "1"
    },
    {
        "zone_id": "112",
        "country_id": "4",
        "name": "الفويلق",
        "name_ar": "الفويلق",
        "code": "الفويلق",
        "status": "1"
    },
    {
        "zone_id": "122",
        "country_id": "4",
        "name": "القريات",
        "name_ar": "القريات",
        "code": "القريات",
        "status": "1"
    },
    {
        "zone_id": "60",
        "country_id": "4",
        "name": "القرينة",
        "name_ar": "القرينة",
        "code": "القرينة",
        "status": "1"
    },
    {
        "zone_id": "58",
        "country_id": "4",
        "name": "القصب",
        "name_ar": "القصب",
        "code": "القصب",
        "status": "1"
    },
    {
        "zone_id": "22",
        "country_id": "4",
        "name": "القصيم",
        "name_ar": "القصيم",
        "code": "QS",
        "status": "1"
    },
    {
        "zone_id": "36",
        "country_id": "4",
        "name": "القطيف",
        "name_ar": "القطيف",
        "code": "القطيف",
        "status": "1"
    },
    {
        "zone_id": "149",
        "country_id": "4",
        "name": "القنفذة",
        "name_ar": "القنفذة",
        "code": "القنفذة",
        "status": "1"
    },
    {
        "zone_id": "94",
        "country_id": "4",
        "name": "القوارة",
        "name_ar": "القوارة",
        "code": "القوارة",
        "status": "1"
    },
    {
        "zone_id": "131",
        "country_id": "4",
        "name": "القويعية",
        "name_ar": "القويعية",
        "code": "القويعية",
        "status": "1"
    },
    {
        "zone_id": "194",
        "country_id": "4",
        "name": "الكربوس",
        "name_ar": "الكربوس",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "183",
        "country_id": "4",
        "name": "الليث",
        "name_ar": "الليث",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "207",
        "country_id": "4",
        "name": "المجاردة",
        "name_ar": "المجاردة",
        "code": "المجاردة",
        "status": "1"
    },
    {
        "zone_id": "47",
        "country_id": "4",
        "name": "المجمعة",
        "name_ar": "المجمعة",
        "code": "المجمعة",
        "status": "1"
    },
    {
        "zone_id": "166",
        "country_id": "4",
        "name": "المخواة",
        "name_ar": "المخواة",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "21",
        "country_id": "4",
        "name": "المدينة المنورة",
        "name_ar": "المدينة المنورة",
        "code": "MD",
        "status": "1"
    },
    {
        "zone_id": "105",
        "country_id": "4",
        "name": "المذنب",
        "name_ar": "المذنب",
        "code": "المذنب",
        "status": "1"
    },
    {
        "zone_id": "32",
        "country_id": "4",
        "name": "المزاحمية",
        "name_ar": "المزاحمية",
        "code": "11972",
        "status": "1"
    },
    {
        "zone_id": "84",
        "country_id": "4",
        "name": "المساعدية",
        "name_ar": "المساعدية",
        "code": "المساعدية",
        "status": "1"
    },
    {
        "zone_id": "80",
        "country_id": "4",
        "name": "المشيبة",
        "name_ar": "المشيبة",
        "code": "المشيبة",
        "status": "1"
    },
    {
        "zone_id": "89",
        "country_id": "4",
        "name": "المعشبة",
        "name_ar": "المعشبة",
        "code": "المعشبة",
        "status": "1"
    },
    {
        "zone_id": "144",
        "country_id": "4",
        "name": "المهد",
        "name_ar": "المهد",
        "code": "المهد",
        "status": "1"
    },
    {
        "zone_id": "55",
        "country_id": "4",
        "name": "المويه",
        "name_ar": "المويه",
        "code": "المويه",
        "status": "1"
    },
    {
        "zone_id": "110",
        "country_id": "4",
        "name": "النبهانية",
        "name_ar": "النبهانية",
        "code": "النبهانية",
        "status": "1"
    },
    {
        "zone_id": "137",
        "country_id": "4",
        "name": "النعيرية",
        "name_ar": "النعيرية",
        "code": "النعيرية",
        "status": "1"
    },
    {
        "zone_id": "139",
        "country_id": "4",
        "name": "النماص",
        "name_ar": "النماص",
        "code": "النماص",
        "status": "1"
    },
    {
        "zone_id": "187",
        "country_id": "4",
        "name": "النوارية",
        "name_ar": "النوارية",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "148",
        "country_id": "4",
        "name": "الهفوف و المبرز",
        "name_ar": "الهفوف و المبرز",
        "code": "الهفوف و المبرز",
        "status": "1"
    },
    {
        "zone_id": "178",
        "country_id": "4",
        "name": "الواديين",
        "name_ar": "الواديين",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "180",
        "country_id": "4",
        "name": "الوجه",
        "name_ar": "الوجه",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "201",
        "country_id": "4",
        "name": "بارق",
        "name_ar": "بارق",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "192",
        "country_id": "4",
        "name": "بحرة",
        "name_ar": "بحرة",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "145",
        "country_id": "4",
        "name": "بدر",
        "name_ar": "بدر",
        "code": "بدر",
        "status": "1"
    },
    {
        "zone_id": "92",
        "country_id": "4",
        "name": "بريدة",
        "name_ar": "بريدة",
        "code": "بريدة",
        "status": "1"
    },
    {
        "zone_id": "135",
        "country_id": "4",
        "name": "بقيق",
        "name_ar": "بقيق",
        "code": "بقيق",
        "status": "1"
    },
    {
        "zone_id": "174",
        "country_id": "4",
        "name": "بللسمر",
        "name_ar": "بللسمر",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "73",
        "country_id": "4",
        "name": "بنبان",
        "name_ar": "بنبان",
        "code": "بنبان",
        "status": "1"
    },
    {
        "zone_id": "128",
        "country_id": "4",
        "name": "بيش",
        "name_ar": "بيش",
        "code": "بيش",
        "status": "1"
    },
    {
        "zone_id": "50",
        "country_id": "4",
        "name": "بيشة",
        "name_ar": "بيشة",
        "code": "بيشة",
        "status": "1"
    },
    {
        "zone_id": "30",
        "country_id": "4",
        "name": "تبوك",
        "name_ar": "تبوك",
        "code": "TB",
        "status": "1"
    },
    {
        "zone_id": "141",
        "country_id": "4",
        "name": "تثليث",
        "name_ar": "تثليث",
        "code": "تثليث",
        "status": "1"
    },
    {
        "zone_id": "185",
        "country_id": "4",
        "name": "تربة",
        "name_ar": "تربة",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "77",
        "country_id": "4",
        "name": "تمير",
        "name_ar": "تمير",
        "code": "تمير",
        "status": "1"
    },
    {
        "zone_id": "78",
        "country_id": "4",
        "name": "تميرية",
        "name_ar": "تميرية",
        "code": "تميرية",
        "status": "1"
    },
    {
        "zone_id": "163",
        "country_id": "4",
        "name": "تيماء",
        "name_ar": "تيماء",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "91",
        "country_id": "4",
        "name": "ثادق",
        "name_ar": "ثادق",
        "code": "ثادق",
        "status": "1"
    },
    {
        "zone_id": "57",
        "country_id": "4",
        "name": "ثرمداء",
        "name_ar": "ثرمداء",
        "code": "ثرمداء",
        "status": "1"
    },
    {
        "zone_id": "189",
        "country_id": "4",
        "name": "ثول",
        "name_ar": "ثول",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "27",
        "country_id": "4",
        "name": "جازان",
        "name_ar": "جازان",
        "code": "JZ",
        "status": "1"
    },
    {
        "zone_id": "34",
        "country_id": "4",
        "name": "جدة",
        "name_ar": "جدة",
        "code": "Jeddah ",
        "status": "1"
    },
    {
        "zone_id": "79",
        "country_id": "4",
        "name": "جلاجل",
        "name_ar": "جلاجل",
        "code": "جلاجل",
        "status": "1"
    },
    {
        "zone_id": "26",
        "country_id": "4",
        "name": "حائل",
        "name_ar": "حائل",
        "code": "HL",
        "status": "1"
    },
    {
        "zone_id": "186",
        "country_id": "4",
        "name": "حالة عمار",
        "name_ar": "حالة عمار",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "82",
        "country_id": "4",
        "name": "حرمة",
        "name_ar": "حرمة",
        "code": "حرمة",
        "status": "1"
    },
    {
        "zone_id": "59",
        "country_id": "4",
        "name": "حريملاء",
        "name_ar": "حريملاء",
        "code": "حريملاء",
        "status": "1"
    },
    {
        "zone_id": "39",
        "country_id": "4",
        "name": "حفر الباطن",
        "name_ar": "حفر الباطن",
        "code": "حفر الباطن",
        "status": "1"
    },
    {
        "zone_id": "202",
        "country_id": "4",
        "name": "حقل",
        "name_ar": "حقل",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "69",
        "country_id": "4",
        "name": "حوطة بني تميم",
        "name_ar": "حوطة بني تميم",
        "code": "حوطة بني تميم",
        "status": "1"
    },
    {
        "zone_id": "86",
        "country_id": "4",
        "name": "حوطة سدير",
        "name_ar": "حوطة سدير",
        "code": "حوطة سدير",
        "status": "1"
    },
    {
        "zone_id": "191",
        "country_id": "4",
        "name": "خليص",
        "name_ar": "خليص",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "37",
        "country_id": "4",
        "name": "خميس مشيط",
        "name_ar": "خميس مشيط",
        "code": "خميس مشيط",
        "status": "1"
    },
    {
        "zone_id": "165",
        "country_id": "4",
        "name": "خيبر",
        "name_ar": "خيبر",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "53",
        "country_id": "4",
        "name": "دومة الجندل",
        "name_ar": "دومة الجندل",
        "code": "دومة الجندل",
        "status": "1"
    },
    {
        "zone_id": "136",
        "country_id": "4",
        "name": "رأس تنورة",
        "name_ar": "رأس تنورة",
        "code": "رأس تنورة",
        "status": "1"
    },
    {
        "zone_id": "160",
        "country_id": "4",
        "name": "رابغ",
        "name_ar": "رابغ",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "175",
        "country_id": "4",
        "name": "رجال المع",
        "name_ar": "رجال المع",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "52",
        "country_id": "4",
        "name": "رفحاء",
        "name_ar": "رفحاء",
        "code": "رفحاء",
        "status": "1"
    },
    {
        "zone_id": "132",
        "country_id": "4",
        "name": "رماح",
        "name_ar": "رماح",
        "code": "رماح",
        "status": "1"
    },
    {
        "zone_id": "206",
        "country_id": "4",
        "name": "رنية",
        "name_ar": "رنية",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "85",
        "country_id": "4",
        "name": "روضة سدير",
        "name_ar": "روضة سدير",
        "code": "روضة سدير",
        "status": "1"
    },
    {
        "zone_id": "107",
        "country_id": "4",
        "name": "رياض الخبراء",
        "name_ar": "رياض الخبراء",
        "code": "رياض الخبراء",
        "status": "1"
    },
    {
        "zone_id": "205",
        "country_id": "4",
        "name": "ساجر",
        "name_ar": "ساجر",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "176",
        "country_id": "4",
        "name": "سبت العلايا",
        "name_ar": "سبت العلايا",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "76",
        "country_id": "4",
        "name": "سدير",
        "name_ar": "سدير",
        "code": "سدير",
        "status": "1"
    },
    {
        "zone_id": "140",
        "country_id": "4",
        "name": "سراة عبيدة",
        "name_ar": "سراة عبيدة",
        "code": "سراة عبيدة",
        "status": "1"
    },
    {
        "zone_id": "121",
        "country_id": "4",
        "name": "سكاكا",
        "name_ar": "سكاكا",
        "code": "سكاكا",
        "status": "1"
    },
    {
        "zone_id": "198",
        "country_id": "4",
        "name": "سلوى",
        "name_ar": "سلوى",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "126",
        "country_id": "4",
        "name": "سيهات",
        "name_ar": "سيهات",
        "code": "سيهات",
        "status": "1"
    },
    {
        "zone_id": "124",
        "country_id": "4",
        "name": "شروره",
        "name_ar": "شروره",
        "code": "شروره",
        "status": "1"
    },
    {
        "zone_id": "49",
        "country_id": "4",
        "name": "شقراء",
        "name_ar": "شقراء",
        "code": "شقراء",
        "status": "1"
    },
    {
        "zone_id": "150",
        "country_id": "4",
        "name": "صامطه",
        "name_ar": "صامطه",
        "code": "صامطه",
        "status": "1"
    },
    {
        "zone_id": "127",
        "country_id": "4",
        "name": "صبياء",
        "name_ar": "صبياء",
        "code": "صبياء",
        "status": "1"
    },
    {
        "zone_id": "161",
        "country_id": "4",
        "name": "صفوى",
        "name_ar": "صفوى",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "90",
        "country_id": "4",
        "name": "صلبوخ",
        "name_ar": "صلبوخ",
        "code": "صلبوخ",
        "status": "1"
    },
    {
        "zone_id": "41",
        "country_id": "4",
        "name": "ضباء",
        "name_ar": "ضباء",
        "code": "ضباء",
        "status": "1"
    },
    {
        "zone_id": "33",
        "country_id": "4",
        "name": "ضرماء",
        "name_ar": "ضرماء",
        "code": "11923",
        "status": "1"
    },
    {
        "zone_id": "196",
        "country_id": "4",
        "name": "ضمد",
        "name_ar": "ضمد",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "164",
        "country_id": "4",
        "name": "طبرجل",
        "name_ar": "طبرجل",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "167",
        "country_id": "4",
        "name": "طريف",
        "name_ar": "طريف",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "173",
        "country_id": "4",
        "name": "ظهران الجنوب ",
        "name_ar": "ظهران الجنوب ",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "45",
        "country_id": "4",
        "name": "عرعر",
        "name_ar": "عرعر",
        "code": "عرعر",
        "status": "1"
    },
    {
        "zone_id": "193",
        "country_id": "4",
        "name": "عسفان",
        "name_ar": "عسفان",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "25",
        "country_id": "4",
        "name": "عسير",
        "name_ar": "عسير",
        "code": "AS",
        "status": "1"
    },
    {
        "zone_id": "87",
        "country_id": "4",
        "name": "عشيرة سدير",
        "name_ar": "عشيرة سدير",
        "code": "عشيرة سدير",
        "status": "1"
    },
    {
        "zone_id": "119",
        "country_id": "4",
        "name": "عفيف",
        "name_ar": "عفيف",
        "code": "عفيف",
        "status": "1"
    },
    {
        "zone_id": "111",
        "country_id": "4",
        "name": "عقلة الصقور",
        "name_ar": "عقلة الصقور",
        "code": "عقلة الصقور",
        "status": "1"
    },
    {
        "zone_id": "102",
        "country_id": "4",
        "name": "عنيزة",
        "name_ar": "عنيزة",
        "code": "عنيزة",
        "status": "1"
    },
    {
        "zone_id": "88",
        "country_id": "4",
        "name": "عودة سدير",
        "name_ar": "عودة سدير",
        "code": "عودة سدير",
        "status": "1"
    },
    {
        "zone_id": "99",
        "country_id": "4",
        "name": "عين بفهيد",
        "name_ar": "عين بفهيد",
        "code": "عين بفهيد",
        "status": "1"
    },
    {
        "zone_id": "200",
        "country_id": "4",
        "name": "عين فهيد",
        "name_ar": "عين فهيد",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "93",
        "country_id": "4",
        "name": "عيون الجواء",
        "name_ar": "عيون الجواء",
        "code": "عيون الجواء",
        "status": "1"
    },
    {
        "zone_id": "195",
        "country_id": "4",
        "name": "فرسان",
        "name_ar": "فرسان",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "138",
        "country_id": "4",
        "name": "قرية العلياء",
        "name_ar": "قرية العلياء",
        "code": "قرية العلياء",
        "status": "1"
    },
    {
        "zone_id": "113",
        "country_id": "4",
        "name": "قصر بن عقيل",
        "name_ar": "قصر بن عقيل",
        "code": "قصر بن عقيل",
        "status": "1"
    },
    {
        "zone_id": "63",
        "country_id": "4",
        "name": "قصور المقبل",
        "name_ar": "قصور المقبل",
        "code": "قصور المقبل",
        "status": "1"
    },
    {
        "zone_id": "97",
        "country_id": "4",
        "name": "قصيباء",
        "name_ar": "قصيباء",
        "code": "قصيباء",
        "status": "1"
    },
    {
        "zone_id": "51",
        "country_id": "4",
        "name": "محايل عسير",
        "name_ar": "محايل عسير",
        "code": "محايل عسير",
        "status": "1"
    },
    {
        "zone_id": "179",
        "country_id": "4",
        "name": "مرات",
        "name_ar": "مرات",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "190",
        "country_id": "4",
        "name": "مستورة",
        "name_ar": "مستورة",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "28",
        "country_id": "4",
        "name": "مكه المكرمه",
        "name_ar": "مكه المكرمه",
        "code": "ML",
        "status": "1"
    },
    {
        "zone_id": "74",
        "country_id": "4",
        "name": "ملهم",
        "name_ar": "ملهم",
        "code": "ملهم",
        "status": "1"
    },
    {
        "zone_id": "83",
        "country_id": "4",
        "name": "مليح",
        "name_ar": "مليح",
        "code": "مليح",
        "status": "1"
    },
    {
        "zone_id": "188",
        "country_id": "4",
        "name": "مهد الذهب",
        "name_ar": "مهد الذهب",
        "code": "",
        "status": "1"
    },
    {
        "zone_id": "29",
        "country_id": "4",
        "name": "نجران",
        "name_ar": "نجران",
        "code": "NR",
        "status": "1"
    },
    {
        "zone_id": "70",
        "country_id": "4",
        "name": "نعام",
        "name_ar": "نعام",
        "code": "نعام",
        "status": "1"
    },
    {
        "zone_id": "66",
        "country_id": "4",
        "name": "هيت",
        "name_ar": "هيت",
        "code": "هيت",
        "status": "1"
    },
    {
        "zone_id": "48",
        "country_id": "4",
        "name": "وادي الدواسر",
        "name_ar": "وادي الدواسر",
        "code": "وادي الدواسر",
        "status": "1"
    },
    {
        "zone_id": "43",
        "country_id": "4",
        "name": "ينبع البحر",
        "name_ar": "ينبع البحر",
        "code": "ينبع البحر",
        "status": "1"
    }
];