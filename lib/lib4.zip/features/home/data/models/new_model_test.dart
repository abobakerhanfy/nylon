import 'package:nylon/features/home/data/models/big_banner.dart';
import 'package:nylon/features/home/data/models/category_menu.dart';
import 'package:nylon/features/home/data/models/mobile_featured.dart';
import 'package:nylon/features/home/data/models/mobile_slider.dart';
import 'package:nylon/features/home/data/models/multi_banner.dart';
import 'package:nylon/features/home/data/models/products_featured.dart';

class NewModelHome {
  List<MultiBanner>? multiBanner;
  List<ProductsFeatured>? productsFeatured;
  List<BigBanner>? bigBanner;
  List<MobileFeatured>? mobileFeatured;
  List<CategoryMenu>? categoryMenu;
  List<MobileSlider>? mobileSlider;

  NewModelHome(
      {this.multiBanner,
      this.productsFeatured,
      this.bigBanner,
      this.mobileFeatured,
      this.categoryMenu,
      this.mobileSlider});

  NewModelHome.fromJson(Map<String, dynamic> json) {
    if (json['multi_banner'] != null) {
      multiBanner = <MultiBanner>[];
      json['multi_banner'].forEach((v) {
        multiBanner!.add(new MultiBanner.fromJson(v));
      });
    }
    if (json['products_featured'] != null) {
      productsFeatured = <ProductsFeatured>[];
      json['products_featured'].forEach((v) {
        productsFeatured!.add(new ProductsFeatured.fromJson(v));
      });
    }
    if (json['big_banner'] != null) {
      bigBanner = <BigBanner>[];
      json['big_banner'].forEach((v) {
        bigBanner!.add(new BigBanner.fromJson(v));
      });
    }
    if (json['mobile_featured'] != null) {
      mobileFeatured = <MobileFeatured>[];
      json['mobile_featured'].forEach((v) {
        mobileFeatured!.add(new MobileFeatured.fromJson(v));
      });
    }
    if (json['category_menu'] != null) {
      categoryMenu = <CategoryMenu>[];
      json['category_menu'].forEach((v) {
        categoryMenu!.add(new CategoryMenu.fromJson(v));
      });
    }
    if (json['mobile_slider'] != null) {
      mobileSlider = <MobileSlider>[];
      json['mobile_slider'].forEach((v) {
        mobileSlider!.add(new MobileSlider.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.multiBanner != null) {
      data['multi_banner'] = this.multiBanner!.map((v) => v.toJson()).toList();
    }
    if (this.productsFeatured != null) {
      data['products_featured'] =
          this.productsFeatured!.map((v) => v.toJson()).toList();
    }
    if (this.bigBanner != null) {
      data['big_banner'] = this.bigBanner!.map((v) => v.toJson()).toList();
    }
    if (this.mobileFeatured != null) {
      data['mobile_featured'] =
          this.mobileFeatured!.map((v) => v.toJson()).toList();
    }
    if (this.categoryMenu != null) {
      data['category_menu'] =
          this.categoryMenu!.map((v) => v.toJson()).toList();
    }
    if (this.mobileSlider != null) {
      data['mobile_slider'] =
          this.mobileSlider!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}










