import 'package:nylon/features/home/data/models/mobile_featured.dart';

class SearchModel {
  ProductsData? products;
  String? moreResults;

  SearchModel({this.products, this.moreResults});

  SearchModel.fromJson(Map<String, dynamic> json) {
    products = json['products'] != null
        ? new ProductsData.fromJson(json['products'])
        : null;
    moreResults = json['more_results'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.products != null) {
      data['products'] = this.products!.toJson();
    }
    data['more_results'] = this.moreResults;
    return data;
  }
}

class ProductsData {
  List<Products>? products;

  ProductsData({this.products});

  ProductsData.fromJson(Map<String, dynamic> json) {
    if (json['products'] != null) {
      products = <Products>[];
      json['products'].forEach((v) {
        products!.add(new Products.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.products != null) {
      data['products'] = this.products!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Products extends Productss {
  String? productIdP;
  String? thumb;
  dynamic priceP;
  dynamic specialP;
  String? nameP;
  String? href;

  Products(
      {this.productIdP,
      this.thumb,
      this.priceP,
      this.specialP,
      this.nameP,
      this.href,
      required super.name,
      required super.productId,
      required super.price,
      required super.image,
      required super.special});

  factory Products.fromJson(Map<String, dynamic> json) {
    return Products(
      name: json['name'],
      productId: json['product_id'],
      price: json['price'],
      image: json['thumb'],
      productIdP: json['product_id'],
      thumb: json['thumb'],
      priceP: json['price'],
      special: json['special'],
      nameP: json['name'],
      href: json['href'],
    );
  }
}
