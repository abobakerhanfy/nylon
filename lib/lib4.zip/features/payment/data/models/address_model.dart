class AddressModel {
  String address;
  String phone;
  String city;
 String type;

  AddressModel({
    required this.address,
    required this.phone,
    required this.city,
    required this.type,
  });
}