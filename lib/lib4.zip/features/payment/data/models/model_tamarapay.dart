class TamarapayModel {
  String? success;
  CheckoutData? checkoutData;
  TamarapayModel({this.success, this.checkoutData});

  TamarapayModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    checkoutData = json['checkout_data'] != null
        ? new CheckoutData.fromJson(json['checkout_data'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    if (this.checkoutData != null) {
      data['checkout_data'] = this.checkoutData!.toJson();
    }
    return data;
  }
}

class CheckoutData {
  String? checkoutSuccessUrl;
  String? checkoutFailureUrl;
  String? checkoutCancelUrl;
  int? opencartOrderId;
  String? tamaraOrderId;
  String? checkoutRedirectUrl;

  CheckoutData(
      {this.checkoutSuccessUrl,
      this.checkoutFailureUrl,
      this.checkoutCancelUrl,
      this.opencartOrderId,
      this.tamaraOrderId,
      this.checkoutRedirectUrl});

  CheckoutData.fromJson(Map<String, dynamic> json) {
    checkoutSuccessUrl = json['checkout_success_url'];
    checkoutFailureUrl = json['checkout_failure_url'];
    checkoutCancelUrl = json['checkout_cancel_url'];
    opencartOrderId = json['opencart_order_id'];
    tamaraOrderId = json['tamara_order_id'];
    checkoutRedirectUrl = json['checkout_redirect_url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['checkout_success_url'] = this.checkoutSuccessUrl;
    data['checkout_failure_url'] = this.checkoutFailureUrl;
    data['checkout_cancel_url'] = this.checkoutCancelUrl;
    data['opencart_order_id'] = this.opencartOrderId;
    data['tamara_order_id'] = this.tamaraOrderId;
    data['checkout_redirect_url'] = this.checkoutRedirectUrl;
    return data;
  }
}