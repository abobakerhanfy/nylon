import 'package:get/get.dart';

import '../services/services.dart';

String? translate (String? ar , String? en){
  MyServices _myServices = Get.find();
  if(_myServices.sharedPreferences.getString('Lang')=='ar'){
    return ar;
  }else{
    return en;
  }
}