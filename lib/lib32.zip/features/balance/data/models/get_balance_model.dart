class GetBalanceModel {
  String? customerId;
  int? balance;

  GetBalanceModel({this.customerId, this.balance});

  GetBalanceModel.fromJson(Map<String, dynamic> json) {
    customerId = json['customer_id'];
    balance = json['balance'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['customer_id'] = customerId;
    data['balance'] = balance;
    return data;
  }
}
