
class StaticAppImages {
  static const String imageLogo = 'images/logo.png';
  static const String borderImage = 'images/coffeeImage.png';
}