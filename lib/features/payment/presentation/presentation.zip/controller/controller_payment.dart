import 'dart:io';
import 'dart:convert'; // Added for jsonDecode

import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:nylon/core/function/snack_bar.dart';
import 'package:nylon/core/function/status_request.dart';
import 'package:nylon/core/url/url_api.dart';
import 'package:nylon/core/widgets/login/dialog.dart';
import 'package:nylon/core/widgets/primary_button.dart';
import 'package:nylon/features/balance/presentation/controller/controller_balance.dart';
import 'package:nylon/features/orders/presentation/controller/controller_order.dart';
import 'package:nylon/features/payment/data/data_sources/payment_data_source.dart';
import 'package:nylon/features/payment/data/models/address_model.dart';
import 'package:nylon/features/payment/data/models/model_myfatoorah.dart';
import 'package:nylon/features/payment/data/models/test_zone.dart';
import 'package:nylon/features/payment/data/models/model_tamarapay.dart';
import 'package:nylon/features/payment/data/models/payment_model.dart';
import 'package:nylon/features/payment/data/models/select_patment.dart';
import 'package:nylon/features/payment/data/models/zone_id_city.dart';
import 'package:nylon/features/shipping/presentation/controller/controller_shipping.dart';
import 'package:nylon/features/cart/presentation/controller/controller_cart.dart';
import 'package:nylon/features/profile/presentation/controller/controller_user.dart';
import 'package:nylon/features/profile/data/models/address_list_model.dart';
import 'package:nylon/features/profile/data/data_sources/profile_data_source.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

abstract class PaymentController extends GetxController {
  Future addAddressPayment();
  Future getPayment();
  Future selectPayment({required String paymentCode});
  void selectCode({required String code, required String title});
  Future getZoneId();
  Future addIamgeBankTr();
  Future confirmBankTransfer();
  Future paymentMyFatoorah();
  Future paymentTamaraPay();
  Future checkTamaraPaymentStatus();
  Future checkPayment();
  Future<void> fetchUserAddresses();
  Future<void> selectAddress(String addressId);
  Future paymentMyFatoorahBlance();
  Future paymentTabby();
}

class ControllerPayment extends PaymentController {
  final PaymentDataSourceImpl _paymentDataSourceImpl =
      PaymentDataSourceImpl(Get.find());
  final ProfileDataSourceImpl _profileDataSourceImpl =
      ProfileDataSourceImpl(Get.find());
  final ControllerShipping _controllerShipping = Get.put(ControllerShipping());
  GlobalKey<FormState> formAddAddress = GlobalKey<FormState>();
  GlobalKey<FormState> formMyFatoorahCard = GlobalKey<FormState>();
  PaymentModel? paymentModel;
  List<PaymentsData> paymentsDataList = [];
  String selectCodePayment = '';
  String titlePayment = '';
  StatusRequest? statusRequestAddAddress,
      statusRequestGetZone,
      statusRequestsendCode,
      statusRequestsendCodeFuser,
      statusRequestGetPayment,
      statusRequestSelectPayment,
      statusRequestAddCustomer,
      statusRequestpMyFatoorah,
      statusRequestTamaraPay,
      statusRequestCheckTamara,
      statusRequestConfBank,
      statusRequestAddImage;

  AddressModel? allAddress;
  ModelMyFatoorah? modelMyFatoorah;
  TamarapayModel? tamarapayModel;
  final TextEditingController cFirstName = TextEditingController();
  final TextEditingController cLastName = TextEditingController();
  final TextEditingController cAddress = TextEditingController();
  final TextEditingController cCitys = TextEditingController();
  final TextEditingController cCountryId = TextEditingController();
  final TextEditingController cZoneId = TextEditingController();
  final TextEditingController cPhone = TextEditingController();
  final TextEditingController cEmail = TextEditingController();
  var cCardName = TextEditingController();
  var cCardnumber = TextEditingController();
  var cExpirationDate = TextEditingController();
  var cSecurityCode = TextEditingController();
  bool isAddressConfirmed = false;
  List<Zone> zoneId = [];
  File? file;
  final _imagePicker = ImagePicker();
  bool isReturningFromPayment = false;
  bool checkPaymentValue = false;

  List<Address> userAddresses = [];
  String? selectedAddressId;
  StatusRequest? statusRequestGetAddresses;

  @override
  void onInit() {
    getPayment();
    fetchUserAddresses();
    getZoneId();

    super.onInit();
  }

  @override
  Future addAddressPayment() async {
    var validator = formAddAddress.currentState;
    if (validator!.validate()) {
      statusRequestAddAddress = StatusRequest.loading;
      update();
      Map<String, dynamic> data = {
        'firstname': cFirstName.text,
        'lastname': cLastName.text,
        'address_1': cAddress.text,
        'city': cCitys.text,
        'country_id': cCountryId.text.isNotEmpty ? cCountryId.text : '0',
        'zone_id': cZoneId.text.isNotEmpty ? cZoneId.text : '0',
      };

      var response = await _paymentDataSourceImpl.addAddressPayment(data: data);
      await _controllerShipping.addAddressShipping(data: data);
      return response.fold((failure) {
        statusRequestAddAddress = failure;
        print("Error adding payment address: $failure");
        showSnackBar("187".tr);
        update();
      }, (data) {
        if (data.containsKey("error")) {
          var errorData = data["error"];
          if (errorData is Map && errorData.isNotEmpty) {
            showSnackBar('${errorData.values.first}');
            statusRequestAddAddress = StatusRequest.failure;
          } else {
            showSnackBar(data["error"].toString());
            statusRequestAddAddress = StatusRequest.failure;
          }
          update();
        } else if (data.containsKey("success")) {
          statusRequestAddAddress = StatusRequest.success;
          getPayment();
          _controllerShipping.getShippingMethods();
          fetchUserAddresses();
          print("Successfully added address: $data");
          cFirstName.clear();
          cLastName.clear();
          cAddress.clear();
          cCitys.clear();
          cCountryId.clear();
          cZoneId.clear();
          update();
          // Corrected showSnackBar call: removed getXSnackBar argument
          showSnackBar("188".tr);
        }
      });
    }
  }

  @override
  Future getPayment() async {
    statusRequestGetPayment = StatusRequest.loading;
    update();
    var response = await _paymentDataSourceImpl.getPayment();
    return response.fold((failure) {
      statusRequestGetPayment = failure;
      print('Error getting payment methods: $failure');
      update();
    }, (data) async {
      if (data.containsKey("error")) {
        statusRequestGetPayment = StatusRequest.badRequest;
        print('Error response getting payment methods: ${data["error"]}');
        update();
      } else {
        try {
          paymentModel = PaymentModel.fromJson(data as Map<String, dynamic>);
          paymentsDataList =
              await paymentModel!.paymentMethods!.toPaymentsDataList();
          print('Fetched ${paymentsDataList.length} payment methods.');
          statusRequestGetPayment = StatusRequest.success;
        } catch (e) {
          print('Error parsing payment methods: $e');
          statusRequestGetPayment = StatusRequest.serverFailure;
        }
        update();
      }
    });
  }

  SelectPaymentModel? selectPaymentModel;
  @override
  Future selectPayment({required String paymentCode}) async {
    statusRequestSelectPayment = StatusRequest.loading;
    update();
    var response =
        await _paymentDataSourceImpl.selectPayment(paymentCode: paymentCode);
    return response.fold((failure) {
      statusRequestSelectPayment = failure;
      print('Error selecting payment: $failure');
      update();
    }, (data) {
      if (data.containsKey("error")) {
        showSnackBar('${data["error"]}');
        statusRequestSelectPayment = StatusRequest.failure;
        print('Error response selecting payment: ${data["error"]}');
        update();
      } else if (data.containsKey("success")) {
        try {
          selectPaymentModel =
              SelectPaymentModel.fromJson(data as Map<String, dynamic>);
          print(
              'Selected payment successfully. Order ID: ${selectPaymentModel!.orderId}');
          statusRequestSelectPayment = StatusRequest.success;
          Get.snackbar(
            'جاري تحديث الفاتورة',
            '',
            snackPosition: SnackPosition.BOTTOM,
            duration: Duration(seconds: 1),
            showProgressIndicator: true,
          );

          Future.delayed(Duration(milliseconds: 700), () {
            getPayment();
          });
        } catch (e) {
          print('Error parsing select payment response: $e');
          statusRequestSelectPayment = StatusRequest.serverFailure;
        }
        update();
      }
    });
  }

  Function(bool?)? onChanged(value) {
    isAddressConfirmed = value ?? false;
    update();
    return null;
  }

  Future addImagesPicker() async {
    try {
      var imagePath = await _imagePicker.pickImage(
          source: ImageSource.gallery, maxWidth: 250, imageQuality: 50);
      if (imagePath != null) {
        file = File(imagePath.path);
        print('Image picked: ${file!.path}');
        update();
      }
    } catch (e) {
      print('Error picking image: $e');
    }
  }

  @override
  void selectCode({required String code, required String title}) {
    if (selectCodePayment == code) return;
    selectCodePayment = code;
    titlePayment = title;
    print('Selected payment code: $selectCodePayment');
    update();
    Get.find<ControllerCart>().getCart();
  }

  Future<void> fetchZones() async {
    try {
      final response = await http.get(Uri.parse(AppApi.getZoneUrl));
      if (response.statusCode == 200) {
        List<dynamic> decodedData = jsonDecode(response.body);
        // Ensure correct parsing if Zone.fromJson expects Map<String, dynamic>
        zoneId = decodedData
            .whereType<Map<String, dynamic>>()
            .map((zoneData) => Zone.fromJson(zoneData))
            .toList();
        print('Fetched ${zoneId.length} zones.');
        update();
      } else {
        throw Exception('Failed to load zones: ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching zones: $e');
    }
  }

  @override
  Future getZoneId() async {
    print('✅ Loading zones from test_zone.dart...');
    statusRequestGetZone = StatusRequest.loading;
    update();

    try {
      zoneId = test.map((json) => Zone.fromJson(json)).toList();

      print('✅ Loaded ${zoneId.length} zones from local test data.');
      statusRequestGetZone = StatusRequest.success;
      update();
    } catch (e) {
      print('❌ Error loading zones from test_zone.dart: $e');
      statusRequestGetZone = StatusRequest.failure;
      update();
    }
  }

  @override
  Future addIamgeBankTr() async {
    if (selectCodePayment == 'bank_transfer' &&
        file != null &&
        file!.path.isNotEmpty) {
      statusRequestAddImage = StatusRequest.loading;
      update();
      var response =
          await _paymentDataSourceImpl.addImageBankTrans(file: file!);
      return response.fold((failure) {
        statusRequestAddImage = failure;
        print('Error uploading bank transfer image: $failure');
        update();
      }, (data) {
        if (data.containsKey("success")) {
          statusRequestAddImage = StatusRequest.success;
          print("Bank transfer image uploaded successfully: $data");
          update();
        } else {
          statusRequestAddImage = StatusRequest.failure;
          print(
              "Failed to upload bank transfer image: ${data['error'] ?? 'Unknown error'}");
          newCustomDialog(
              body: SizedBox(
                height: 40,
                child: PrimaryButton(
                  label: '100'.tr,
                  onTap: () {
                    Get.back();
                  },
                ),
              ),
              title: "180".tr,
              dialogType: DialogType.error);
          update();
        }
      });
    } else {
      print(
          'Cannot upload image: Payment method is not bank transfer or file is missing.');
      if (selectCodePayment != 'bank_transfer') showSnackBar("181".tr);
      if (file == null || file!.path.isEmpty) showSnackBar("182".tr);
    }
  }

  @override
  Future confirmBankTransfer() async {
    statusRequestConfBank = StatusRequest.loading;
    update();
    var response = await _paymentDataSourceImpl.confirmBankTransfer();
    response.fold((failure) {
      statusRequestConfBank = failure;
      print("Error confirming bank transfer: $failure");
      update();
    }, (data) {
      statusRequestConfBank = StatusRequest.success;
      print("Bank transfer confirmed: $data");
      update();
    });
  }

  @override
  Future paymentTamaraPay() async {
    statusRequestTamaraPay = StatusRequest.loading;
    update();
    var response = await _paymentDataSourceImpl.paymentTamaraPay(data: {});
    return response.fold((failure) {
      statusRequestTamaraPay = failure;
      print('Error initiating Tamara Pay: $failure');
      update();
    }, (data) async {
      if (data.isNotEmpty) {
        try {
          tamarapayModel =
              TamarapayModel.fromJson(data as Map<String, dynamic>);
          if (tamarapayModel!.checkoutData?.checkoutRedirectUrl != null) {
            print(
                'Tamara Pay redirect URL: ${tamarapayModel!.checkoutData!.checkoutRedirectUrl}');
            isReturningFromPayment = true;
            update();
            final Uri url =
                Uri.parse(tamarapayModel!.checkoutData!.checkoutRedirectUrl!);
            if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
              statusRequestTamaraPay = StatusRequest.failure;
              print('Could not launch Tamara Pay URL: $url');
              showSnackBar("183".tr);
              update();
            } else {
              statusRequestTamaraPay = StatusRequest.success;
              print("Tamara Pay launched successfully.");
              update();
            }
          } else {
            statusRequestTamaraPay = StatusRequest.failure;
            print("Tamara Pay error: Missing redirect URL. Response: $data");
            showSnackBar("184".tr);
            update();
          }
        } catch (e) {
          statusRequestTamaraPay = StatusRequest.failure;
          print("Error parsing Tamara Pay response: $e");
          showSnackBar("185".tr);
          update();
        }
      } else {
        statusRequestTamaraPay = StatusRequest.failure;
        print("Tamara Pay error: Empty response data.");
        showSnackBar("184".tr);
        update();
      }
    });
  }

  @override
  Future checkTamaraPaymentStatus() async {
    if (isReturningFromPayment == true &&
        tamarapayModel?.checkoutData?.tamaraOrderId != null) {
      print(
          "Checking Tamara payment status for order ID: ${tamarapayModel!.checkoutData!.tamaraOrderId}");
      statusRequestCheckTamara = StatusRequest.loading;
      update();
      var response = await _paymentDataSourceImpl.checkTamaraPaymentStatus(
          tamaraOrderId: tamarapayModel!.checkoutData!.tamaraOrderId!);
      return response.fold((failure) {
        statusRequestCheckTamara = failure;
        print('Error checking Tamara payment status: $failure');
        update();
      }, (data) async {
        if (data.containsKey("success") && data["success"] == true) {
          statusRequestCheckTamara = StatusRequest.success;
          print("Tamara payment successful: $data");
          update();
          try {
            ControllerOrder _controllerOrder = Get.find();
            await _controllerOrder.sendOrder();
            print("Order sent after successful Tamara payment.");
          } catch (e) {
            print("Error finding or calling ControllerOrder.sendOrder: $e");
          }
          isReturningFromPayment = false;
          update();
        } else {
          statusRequestCheckTamara = StatusRequest.failure;
          print("Tamara payment check failed or payment not complete: $data");
          newCustomDialog(
              body: SizedBox(
                height: 40,
                child: PrimaryButton(
                  label: '100'.tr,
                  onTap: () {
                    Get.back();
                  },
                ),
              ),
              title: "186".tr,
              dialogType: DialogType.error);
          isReturningFromPayment = false;
          update();
        }
      });
    } else {
      print(
          "Skipping Tamara payment check: Not returning from payment or missing order ID.");
    }
  }

  @override
  Future paymentMyFatoorah() async {
    statusRequestpMyFatoorah = StatusRequest.loading;
    update();
    var validator = formMyFatoorahCard.currentState;
    if (validator!.validate()) {
      var response = await _paymentDataSourceImpl.paymentMyFatoorah(data: {
        "cardholdername": cCardName.text,
        "cardnumber": cCardnumber.text,
        "expirationdate": cExpirationDate.text,
        "securitycode": cSecurityCode.text
      });
      return response.fold((failure) {
        statusRequestpMyFatoorah = failure;
        print('Error initiating MyFatoorah payment: $failure');
        update();
      }, (data) async {
        print('MyFatoorah response: $data');
        if (data.isNotEmpty &&
            data.containsKey("success") &&
            data["success"] == true) {
          try {
            modelMyFatoorah =
                ModelMyFatoorah.fromJson(data as Map<String, dynamic>);
            if (modelMyFatoorah!.success == true &&
                modelMyFatoorah!.paymentUrl != null) {
              checkPaymentValue = true;
              update();
              print('MyFatoorah Payment URL: ${modelMyFatoorah!.paymentUrl}');
              print('MyFatoorah Invoice ID: ${modelMyFatoorah!.invoiceId}');
              final Uri url = Uri.parse(modelMyFatoorah!.paymentUrl!);
              if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
                statusRequestpMyFatoorah = StatusRequest.failure;
                print('Could not launch MyFatoorah URL: $url');
                showSnackBar("183".tr);
                update();
              } else {
                statusRequestpMyFatoorah = StatusRequest.success;
                print("MyFatoorah launched successfully.");
                update();
              }
            } else {
              statusRequestpMyFatoorah = StatusRequest.failure;
              print(
                  "MyFatoorah error: Success false or missing payment URL. Response: $data");
              showSnackBar("184".tr);
              update();
            }
          } catch (e) {
            statusRequestpMyFatoorah = StatusRequest.failure;
            print("Error parsing MyFatoorah response: $e");
            showSnackBar("185".tr);
            update();
          }
        } else {
          statusRequestpMyFatoorah = StatusRequest.failure;
          print(
              "MyFatoorah error: Response indicates failure or missing success key. Response: $data");
          showSnackBar(data['error']?.toString() ?? "184".tr);
          update();
        }
      });
    } else {
      // Corrected: Use a valid StatusRequest value like failure or none if it exists
      // Assuming StatusRequest.none does not exist, using failure
      statusRequestpMyFatoorah = StatusRequest.failure;
      update();
      print("MyFatoorah form validation failed.");
    }
  }

  @override
  Future checkPayment() async {
    if (selectPaymentModel?.orderId == null) {
      print("Cannot check payment: Order ID is missing.");
      return;
    }
    print(
        "Checking payment status for order ID: ${selectPaymentModel!.orderId}");
    update();
    var response = await _paymentDataSourceImpl.checkPayment(
        orderId: selectPaymentModel!.orderId!);
    response.fold((failure) {
      print("Error checking payment status: $failure");
      update();
    }, (data) {
      print("Payment status check response: $data");
      if (data.containsKey("success") && data["success"] == true) {
        print("Payment confirmed via checkPayment.");
      } else {
        print("Payment not confirmed via checkPayment.");
      }
      update();
    });
  }

  @override
  Future<void> fetchUserAddresses() async {
    statusRequestGetAddresses = StatusRequest.loading;
    update();
    print("Fetching user addresses...");
    var response = await _profileDataSourceImpl.getAddresses();
    response.fold(
      (failure) {
        statusRequestGetAddresses = failure;
        print("Failed to fetch addresses: $failure");
        userAddresses = [];
        update();
      },
      (addresses) {
        userAddresses = addresses;
        selectedAddressId = userAddresses
            .firstWhereOrNull((addr) => addr.defaultAddress == true)
            ?.addressId;
        if (selectedAddressId == null && userAddresses.isNotEmpty) {
          selectedAddressId = userAddresses.first.addressId;
          print(
              "No default address found, selecting first address ID: $selectedAddressId");
          if (selectedAddressId != null) {
            print(
                "Auto-selected address. Reloading cart and shipping methods...");
            Get.find<ControllerCart>().getCart();
            _controllerShipping.getShippingMethods();
          }
        }
        statusRequestGetAddresses = StatusRequest.success;
        print(
            "Fetched ${userAddresses.length} addresses. Selected ID: $selectedAddressId");
        update();
      },
    );
  }

  @override
  Future<void> selectAddress(String addressId) async {
    if (selectedAddressId == addressId) {
      print("Address ID $addressId already selected.");
      return;
    }
    print("Selecting address ID: $addressId");
    selectedAddressId = addressId;
    print("Address selected locally. Reloading cart and shipping methods...");
    Get.find<ControllerCart>().getCart();
    _controllerShipping.getShippingMethods();
    update();
  }

  @override
  Future paymentMyFatoorahBlance() async {
    print(
        "Placeholder: paymentMyFatoorahBlance called. Implement actual logic.");
    await Future.delayed(Duration(seconds: 1));
    showSnackBar("Functionality not implemented yet.");
  }

  @override
  Future paymentTabby() async {
    print("Placeholder: paymentTabby called. Implement actual logic.");
    await Future.delayed(Duration(seconds: 1));
    showSnackBar("Functionality not implemented yet.");
  }
}
