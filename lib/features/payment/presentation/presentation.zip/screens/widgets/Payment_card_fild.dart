// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nylon/features/cart/presentation/screens/widgets/field_cart.dart';
import 'package:nylon/features/payment/presentation/controller/controller_payment.dart';

class PaymentCardField extends StatelessWidget {
  PaymentCardField({super.key});

  
    ControllerPayment _controllerPayment = Get.find();
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation:1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Form(
          key: _controllerPayment.formMyFatoorahCard,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "تفاصيل البطاقة",
                style: Theme.of(context).textTheme.bodyMedium
              ),
              const SizedBox(height: 20),
              CustomFiledCart(
                width: double.infinity,
                hint: 'اسم المستخدم',
                controller: _controllerPayment.cCardName,
                icon: Icons.person, // إضافة أيقونة
                validator: (value) => value!.isEmpty ? '163'.tr : null,
              ),
              const SizedBox(height: 15),
              CustomFiledCart(
                width: double.infinity,
                hint: "رقم البطاقة",
                controller: _controllerPayment.cCardnumber,
                icon: Icons.credit_card, // إضافة أيقونة
                validator: (value) => value!.isEmpty ? '163'.tr : null,
              ),
              const SizedBox(height: 15),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CustomFiledCart(
                    width: MediaQuery.of(context).size.width * 0.35,
                    hint: "رمز الأمان",
                    controller: _controllerPayment.cSecurityCode,
                    icon: Icons.lock, // إضافة أيقونة
                    validator: (value) => value!.isEmpty ? '163'.tr : null,
                  ),
                  CustomFiledCart(
                    width: MediaQuery.of(context).size.width * 0.35,
                    hint: "تاريخ الانتهاء",
                    controller: _controllerPayment.cExpirationDate,
                    icon: Icons.calendar_today, // إضافة أيقونة
                    validator: (value) => value!.isEmpty ? '163'.tr : null,
                  ),
                ],
              ),
              // Padding(
              //   padding: const EdgeInsets.all(8.0),
              //   child: Center(
              //     child: InkWell(
              //       onTap: (){
                      
              //       },
              //       child: Text("تم")),
              //   ),
              // )
            ],
          ),
        ),
      ),
    );
  }
}
