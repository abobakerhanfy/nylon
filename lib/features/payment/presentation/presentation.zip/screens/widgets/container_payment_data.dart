import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:nylon/core/theme/colors_app.dart';
import 'package:nylon/core/widgets/cached_network_image.dart';
import 'package:nylon/features/coupon/presentation/screens/widgets/container_copy_past_text.dart';
import 'package:nylon/features/payment/data/models/payment_model.dart';
import 'package:nylon/features/payment/presentation/controller/controller_payment.dart';
import 'package:nylon/features/payment/presentation/screens/widgets/Payment_card_fild.dart';
import 'package:nylon/features/payment/presentation/screens/widgets/payment_Image.dart';

// ignore: must_be_immutable
class ContainerPaymentData extends StatelessWidget {
  final PaymentsData paymentsData;
  final String? codePayment;

  ContainerPaymentData({
    super.key,
    required this.paymentsData,
    this.codePayment,
  });
  bool isSvg(String? url) {
    return url != null && url.trim().toLowerCase().endsWith('.svg');
  }
  @override
  Widget build(BuildContext context) {
    return GetBuilder<ControllerPayment>(
      builder: (_controller) {
        return InkWell(
          onTap: () {
            print(paymentsData.images!.length);
             _controller.selectCode(code:paymentsData.code!,title: paymentsData.separatedText!);
          },
          child:  Container(
           
             // width: MediaQuery.of(context).size.width * 0.90,
             // height:paymentsData.images!.length > 1? 110:50,
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.colorCreditCard,
                borderRadius: BorderRadius.circular(0),
                border: Border.all(
                  color: codePayment == paymentsData.code
                      ? AppColors.primaryColor
                      : AppColors.colorCreditCard,
                  width: 2,
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                     if (paymentsData.images != null && paymentsData.images!.length == 1) ...{
                          isSvg( paymentsData.images!.first??'')?
                          Padding(
        padding: const EdgeInsets.all(4.0),
        child: SvgPicture.network(
           paymentsData.images!.first??'',
          placeholderBuilder: (context) => Center(child: const CircularProgressIndicator()),
       
        ),
      ):
                          SizedBox(
                            height: 50,
                            child:  CachedNetworkImageWidget(
                                      fit: BoxFit.cover,
                                       imageUrl: paymentsData.images!.first??''
                                          ),
                            
                            //  PaymentImageWidget(imageUrl: paymentsData.images!.first),
                          ),
                         
                        },
                                
                        // الحالة عندما يكون هناك أكثر من صورة
                        if (paymentsData.images != null && paymentsData.images!.length > 1)
                      
                             Flexible(
                                 //   width: MediaQuery.of(context).size.width * 0.90,
                                 // height:paymentsData.images!.length > 1? 110:50,
                                child:Container(
                                  width: MediaQuery.of(context).size.width * 0.90,
                                  padding: const EdgeInsets.all(0),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min, 
                                    crossAxisAlignment: CrossAxisAlignment.start,// تحديد حجم العمود بناءً على المحتوى
                                    children: [
                                      SizedBox(
                                       height: 30, // تحديد ارتفاع ثابت للقائمة
                                        child: ListView.separated(
                                          shrinkWrap: true,
                                          scrollDirection: Axis.horizontal,
                                          separatorBuilder: (context, i) => const SizedBox(width: 7),
                                          itemCount: paymentsData.images!.length ?? 0,
                                          itemBuilder: (context, i) {
                                            return PaymentImageWidget(imageUrl: paymentsData.images![i]);
                                          },
                                        ),
                                      ),
                                      const SizedBox(height: 6),
                                      Text(
                                        paymentsData.separatedText != null
                                            ? paymentsData.separatedText!
                                            : '',
                                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                              fontSize: 12,
                                              color: const Color.fromARGB(255, 31, 27, 27),
                                            ),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                  
                                      const SizedBox(height: 5),
                                      if (codePayment == paymentsData.code)
                                        Icon(
                                          Icons.check_circle,
                                          color: AppColors.primaryColor,
                                        ),
                                    ],
                                  ),
                                ),
                              ),
                        
                          if (paymentsData.images != null && paymentsData.images!.length == 1 || paymentsData.images!.isEmpty ) ...{
                            SizedBox(
                              width: MediaQuery.of(context).size.width*0.40,                      
                            child: Text(
                              paymentsData.separatedText != null
                                  ? paymentsData.separatedText!
                                  : '',
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                    fontSize: 12,
                                    color: const Color.fromARGB(255, 31, 27, 27),
                                  ),
                              maxLines:4,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          const Spacer(),
                          if (codePayment == paymentsData.code)
                            Icon(
                              Icons.check_circle,
                              color: AppColors.primaryColor,
                            ),
                             
                          }
                            
                      ],
                      
                    ),
                 if(_controller.selectCodePayment=="bank_transfer"&&paymentsData.code=="bank_transfer")...{
                   Container(
          padding: const EdgeInsets.all(8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Text('178'.tr,style: Theme.of(Get.context!).textTheme.bodyLarge?.copyWith(
                fontWeight: FontWeight.w400
              ),textAlign: TextAlign.center,),
                const   SizedBox(height: 20,),
                 ContainerTextCpoyPast(
                   sizeIcon: 24,
                  title: '179'.tr,
                text:paymentsData.accountNumber!=null? '${paymentsData.accountNumber}':'',
               ),
               const   SizedBox(height: 10,),
                 ContainerTextCpoyPast(
                  sizeIcon: 24,
                  title: 'IBAN',
                text:paymentsData.iBAN!=null? '${paymentsData.iBAN}':'',
               ),
                 const   SizedBox(height: 10,),
                 GetBuilder<ControllerPayment>(
                                builder: (_controllerPayment){
                                  return  
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Flexible(
                                        child: Text('177'.tr,style: Theme.of(context).textTheme.bodySmall,
                                          maxLines: 2,overflow: TextOverflow.ellipsis),
                                      ),
                                     Stack(
                                      alignment: Alignment.topLeft,
                                        children: [
                                          
                                          Container(
                                            height: 95,
                                            width: 75,
                                            decoration: BoxDecoration(
                                               color: Colors.grey[300],
                                              borderRadius:BorderRadius.circular(6)
                                            ),
                                            child:
                                           _controllerPayment.file !=null ?
                                          Image.file(_controllerPayment.file!,fit: BoxFit.fill,):
                                             Center(
                                              child:InkWell(
                                                onTap: ()async{
                                                 await _controllerPayment.addImagesPicker();
                                                },
                                                child: Icon(Icons.upload_file, size: 26, color: Colors.grey[800]))
                                          
                                            ),
                                          ),
                                          if(_controllerPayment.file !=null )
                                          InkWell(
                                            onTap: ()async{
                                                if (_controllerPayment.file != null) {
      try {
        // تحقق من وجود الملف أولاً قبل محاولة حذفه
        if (await _controllerPayment.file!.exists()) {
          await _controllerPayment.file!.delete();
        }
        _controllerPayment.file = null; // تعيين الملف إلى null لإخفائه
        _controllerPayment.update();    // تحديث واجهة المستخدم
      } catch (e) {
        print('Error deleting file: $e');
      }
    }
  },
                                          
                                            child:const  Icon(Icons.clear,size: 16,color: Colors.black,)),
                                        ],
                                      )
                                    ],);
                               
                                },
                               )
               
               
              

            ],
          ),
        ),
         },
          if(_controller.selectCodePayment=='xpayment1'&&paymentsData.code=='xpayment1')...{
                Container(
          padding: const EdgeInsets.all(8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Text('عنوان المتجر : '.tr,style: Theme.of(Get.context!).textTheme.bodyLarge?.copyWith(
                fontWeight: FontWeight.w400
              ),textAlign: TextAlign.center,),
                const   SizedBox(height: 10,),
                Text(" الرياض - حي الزهره - شارع بديع الزمان"
                ,style: Theme.of(context).textTheme.bodySmall,)
            ],
          ),
        ),
                                    }
                 ,
                  if(_controller.selectCodePayment=="myfatoorah_pg"&&paymentsData.code=="myfatoorah_pg")...{
                   PaymentCardField()
                  }
                 
                  ],
                ),
              ),
            ),
       
        );
      },
    );
  }
}
