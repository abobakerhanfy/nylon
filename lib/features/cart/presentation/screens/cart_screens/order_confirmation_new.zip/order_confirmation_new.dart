import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nylon/core/function/hindling_data_view.dart';
import 'package:nylon/core/function/status_request.dart';
import 'package:nylon/core/routes/name_pages.dart';
import 'package:nylon/core/theme/colors_app.dart';
import 'package:nylon/core/widgets/login/dialog.dart';
import 'package:nylon/core/widgets/primary_button.dart';
import 'package:nylon/features/addresses/data/models/address_model.dart';
import 'package:nylon/features/cart/presentation/controller/controller_cart.dart';
import 'package:nylon/features/cart/presentation/screens/widgets/button_on_cart.dart';
import 'package:nylon/features/cart/presentation/screens/widgets/row_invoice.dart';
import 'package:nylon/features/login/presentation/controller/controller_login.dart';
import 'package:nylon/features/orders/presentation/controller/controller_order.dart';
import 'package:nylon/features/orders/presentation/screens/widgets/container_address_details.dart';
import 'package:nylon/features/payment/presentation/controller/controller_payment.dart';
import 'package:nylon/features/payment/presentation/screens/widgets/container_payment_data.dart';
import 'package:nylon/features/shipping/presentation/controller/controller_shipping.dart';

class OrderConfirmationNew extends StatefulWidget {
  OrderConfirmationNew({super.key});

  @override
  State<OrderConfirmationNew> createState() => _OrderConfirmationNewState();
}

class _OrderConfirmationNewState extends State<OrderConfirmationNew> {
  final ControllerCart _controller = Get.put(ControllerCart());
  final ControllerPayment _controllerPayment = Get.put(ControllerPayment());
  final ControllerShipping _controllerShipping = Get.put(ControllerShipping());
  final ControllerOrder _controllerOrder = Get.put(ControllerOrder());
  final ControllerLogin _controllerLogin = Get.put(ControllerLogin());
  @override
  void initState() {
    _controllerPayment.getPayment();
    _controllerLogin.getCustomerBypId();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Container(
        height: 180,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _controller.cartModel!.totals!.length ?? 0,
                  separatorBuilder: (context, i) => SizedBox(
                        height: MediaQuery.of(context).size.height * 0.01,
                      ),
                  itemBuilder: (context, i) {
                    return invoiceRow(
                        title: _controller.cartModel!.totals![i].title!,
                        price: _controller.cartModel!.totals![i].text!);
                  }),
            ),
            GetBuilder<ControllerOrder>(builder: (_controllerOrder) {
              return _controllerOrder.statusRequestSendOrder ==
                      StatusRequest.loading
                  ? Center(
                      child: CircularProgressIndicator(
                        color: AppColors.primaryColor,
                      ),
                    )
                  : ButtonOnCart(
                      width: MediaQuery.of(context).size.width * 0.80,
                      label: '36'.tr,
                      onTap: () async {
                        if (_controllerLogin.selectedAddressId != null &&
                            _controllerPayment.selectCodePayment != '') {
                          // إرسال عنوان المستخدم
                          await _controllerOrder.sendIdAddress(
                              idAddress: _controllerLogin.selectedAddressId!);

                          // اختيار طريقة الدفع
                          await _controllerPayment.selectPayment(
                              paymentCode:
                                  _controllerPayment.selectCodePayment);

                          if (_controllerPayment.selectCodePayment ==
                              'bank_transfer') {
                            if (_controllerPayment.file != null) {
                              // رفع صورة التحويل البنكي
                              await _controllerPayment.addIamgeBankTr();

                              if (_controllerOrder.statusRequestSenIdAddress ==
                                      StatusRequest.success &&
                                  _controllerPayment
                                          .statusRequestSelectPayment ==
                                      StatusRequest.success) {
                                print(
                                    'ssssssssssssssssssssssssssssssssssssssssssssend Order now');

                                await _controllerOrder.sendOrder();
                                await _controllerPayment.confirmBankTransfer();
                              } else {
                                print(
                                    _controllerOrder.statusRequestSenIdAddress);
                                print(_controllerPayment
                                    .statusRequestSelectPayment);

                                _controllerOrder.statusRequestSendOrder =
                                    StatusRequest.failure;
                                _controllerOrder.update();

                                newCustomDialog(
                                  body: SizedBox(
                                    height: 40,
                                    child: PrimaryButton(
                                      label: 'موافق',
                                      onTap: () {
                                        Get.back();
                                      },
                                    ),
                                  ),
                                  title:
                                      'فشل في ارسال البيانات الرجاء المحاولة مره اخري',
                                  dialogType: DialogType.info,
                                );
                              }
                            } else {
                              newCustomDialog(
                                body: SizedBox(
                                  height: 40,
                                  child: PrimaryButton(
                                    label: 'موافق',
                                    onTap: () {
                                      Get.back();
                                    },
                                  ),
                                ),
                                title:
                                    "الرجاء ارسال صوره التحويل \n حتي نتمكن من تنفيذ الطلب ",
                                dialogType: DialogType.info,
                              );
                            }
                          } else if (_controllerPayment.selectCodePayment ==
                              'myfatoorah_pg') {
                            await _controllerPayment.paymentMyFatoorah();
                            // if(_controllerPayment.statusRequestpMyFatoorah!=StatusRequest.success){

                            // }else{
                            //   await _controllerOrder.sendOrder();
                            // }
                          } else if (_controllerPayment.selectCodePayment ==
                              "tamarapay") {
                            await _controllerPayment.paymentTamaraPay();
                          } else if (_controllerPayment.selectCodePayment ==
                              "tabby_cc_installments") {
                            print("tabby_cc_installments ==============");
                            _controllerPayment.paymentTabby();
                          } else {
                            if (_controllerOrder.statusRequestSenIdAddress ==
                                    StatusRequest.success &&
                                _controllerPayment.statusRequestSelectPayment ==
                                    StatusRequest.success) {
                              print(
                                  'ssssssssssssssssssssssssssssssssssssssssssssend Order now');

                              await _controllerOrder.sendOrder();
                            } else {
                              print(_controllerOrder.statusRequestSenIdAddress);
                              print(_controllerPayment
                                  .statusRequestSelectPayment);

                              _controllerOrder.statusRequestSendOrder =
                                  StatusRequest.failure;
                              _controllerOrder.update();

                              newCustomDialog(
                                body: SizedBox(
                                  height: 40,
                                  child: PrimaryButton(
                                    label: 'موافق',
                                    onTap: () {
                                      Get.back();
                                    },
                                  ),
                                ),
                                title:
                                    'فشل في ارسال البيانات الرجاء المحاولة مره اخري',
                                dialogType: DialogType.info,
                              );
                            }
                          }
                        } else {
                          newCustomDialog(
                            body: SizedBox(
                              height: 40,
                              child: PrimaryButton(
                                label: 'موافق',
                                onTap: () {
                                  Get.back();
                                },
                              ),
                            ),
                            title:
                                'الرجاء اختيار العنوان ووسيلة الدفع \n حتي نتمكن من تنفيذ طلبك',
                            dialogType: DialogType.warning,
                          );
                        }

                        // if(_controllerPayment.selectCodePayment=='bank_transfer'&&_controllerPayment.file==null){
                        //       showSnackBar('186'.tr);
                        // }else{
                        //   await _controllerOrder.sendOrder();
                        // if(_controllerOrder.statusRequestSendOrder==StatusRequest.success){
                        //   _controller.plusIndexScreensCart();
                        //  // _controller.getCart();

                        // }else{
                        //   print('errrrrrrrOR uiiiiiiiiiii');
                        // }

                        // }
                      });
            }),
          ],
        ),
      ),
      backgroundColor: Colors.white,
      body: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: LayoutBuilder(
          builder: (context, boxSize) {
            return ListView(
              children: [
                // ignore: prefer_const_constructors
                AddressUserOnCart(),
                const WidgetPaymentDataCart(),
                SizedBox(height: MediaQuery.of(context).size.height * 0.02),
                FreeShipping(
                  hasReachedTarget: _controller.hasReachedTarget,
                ),
                SizedBox(height: MediaQuery.of(context).size.height * 0.02),
              ],
            );
          },
        ),
      ),
    );
  }
}

class AddressUserOnCart extends StatelessWidget {
  const AddressUserOnCart({
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    return GetBuilder<ControllerLogin>(builder: (_contrrolerLogin) {
      return HandlingDataView(
        statusRequest: _contrrolerLogin.statusRequestgetUserBP!,
        widget: GetBuilder<ControllerLogin>(builder: (_contrrolerLogin) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    '175'.tr,
                    style: Theme.of(context)
                        .textTheme
                        .headlineSmall
                        ?.copyWith(color: Colors.black),
                  ),
                  const Spacer(),
                  InkWell(
                    onTap: () {
                      // _controllerPayment.cCitys.clear();
                      Get.toNamed(NamePages.pAddAddress);
                      //pAddAddressShipping)
                    },
                    child: Text(
                      '85'.tr,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  )
                ],
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.02),
              _contrrolerLogin.addressModel?.data!.address != null &&
                      _contrrolerLogin.addressModel!.data!.address!.isNotEmpty
                  ? Container(
                      padding: const EdgeInsets.all(6),
                      color: Colors.white,
                      child: ListView.separated(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: _contrrolerLogin
                                .addressModel!.data!.address?.length ??
                            0,
                        // ignore: prefer_const_constructors
                        separatorBuilder: (context, i) => SizedBox(
                          height: 10,
                        ),
                        itemBuilder: (context, i) {
                          Address address =
                              _contrrolerLogin.addressModel!.data!.address![i];
                          return Container(
                            color: AppColors.background,
                            child: Row(
                              children: [
                                Expanded(
                                  child: AddressDetails(
                                    address:
                                        '${address.address1}\n ${address.address2}',
                                    phone: '',
                                    city: address.city ?? '',
                                  ),
                                ),
                                Checkbox(
                                  value: _contrrolerLogin.selectedAddressId ==
                                      address.addressId,
                                  activeColor: AppColors.primaryColor,
                             onChanged: (bool? value) {
  if (value == true) {
    _contrrolerLogin.onSelectIdAddress(address.addressId!, true);

    // أضف هذا مباشرة بعد الاختيار بدون await
    _updateInvoiceAfterAddressChange(address.addressId!);
  }
},

                                      Get.snackbar('جاري التحديث',
                                          'يتم تحديث الفاتورة...');

                                      Get.dialog(
                                        const Center(
                                            child: CircularProgressIndicator()),
                                        barrierDismissible: false,
                                      );

                                      await Get.find<ControllerOrder>()
                                          .sendIdAddress(
                                              idAddress: address.addressId!);

                                      if (Get.isDialogOpen ?? false) Get.back();
                                    }
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ))
                  : const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Center(
                          child: Text('لم تقم باضافه عنوان حتي الان ..!')),
                    ),
            ],
          );
        }),
        onRefresh: () {
          _contrrolerLogin.getCustomerBypId();
        },
      );
    });
  }
}

class WidgetPaymentDataCart extends StatelessWidget {
  const WidgetPaymentDataCart({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ControllerPayment>(builder: (_controllerPayment) {
      return HandlingDataView(
        statusRequest: _controllerPayment.statusRequestGetPayment!,
        widget: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: MediaQuery.of(context).size.height * 0.02),
            Text(
              '169'.tr,
              style: Theme.of(context)
                  .textTheme
                  .headlineSmall
                  ?.copyWith(color: Colors.black),
            ),
            SizedBox(height: MediaQuery.of(context).size.height * 0.02),
            SizedBox(
              child: ListView.separated(
                padding: const EdgeInsets.all(8),
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                separatorBuilder: (context, i) =>
                    SizedBox(height: MediaQuery.of(context).size.height * 0.02),
                itemCount: _controllerPayment.paymentsDataList.length ?? 0,
                itemBuilder: (context, i) {
                  return ContainerPaymentData(
                    codePayment: _controllerPayment.selectCodePayment,
                    paymentsData: _controllerPayment.paymentsDataList[i],
                  );
                },
              ),
            ),
          ],
        ),
        onRefresh: () {
          _controllerPayment.getPayment();
        },
      );
    });
  }
}

class FreeShipping extends StatelessWidget {
  final bool hasReachedTarget;
  const FreeShipping({
    super.key,
    required this.hasReachedTarget,
  });

  @override
  Widget build(BuildContext context) {
    return hasReachedTarget == true
        ? Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '170'.tr,
                style: Theme.of(context)
                    .textTheme
                    .headlineSmall
                    ?.copyWith(color: Colors.black),
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.02),
              Container(
                width: MediaQuery.of(context).size.width * 0.90,
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                    color: AppColors.colorCreditCard,
                    borderRadius: BorderRadius.circular(0),
                    border:
                        Border.all(color: AppColors.primaryColor, width: 2)),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        flex: 4,
                        child: Text(
                          'شحن مجاني',
                          style: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.copyWith(
                                fontSize: 12,
                                color: const Color.fromARGB(255, 31, 27, 27),
                              ),
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const Spacer(),
                      Icon(
                        Icons.check_circle,
                        color: AppColors.primaryColor,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          )
        : const SizedBox.shrink();
  }
}

                         
                          // Container(
                          //   margin: const EdgeInsets.symmetric(horizontal:6,vertical: 8),
                          //   child: ListView.separated(
                          //     shrinkWrap: true,
                          //     physics:const NeverScrollableScrollPhysics(),
                          //       separatorBuilder: (context,i)=>SizedBox(height: boxSize.maxHeight*0.01,),
                          //       itemCount: _controller.cartModel!.products!.length,
                          //       itemBuilder: (context,i){
                          //         return  ContainerProductCart(products:_controller.cartModel!.products![i],onCart: false,);
                          //       }),
                          // ),
                  
                      //     Padding(
                      //       padding: const EdgeInsets.symmetric(horizontal: 8),
                      //       child: Text("34".tr,style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      //           fontSize: 18
                      //       ),),
                      //     ),
                      //     SizedBox(height: boxSize.maxHeight*0.02,),
                      //     Center(
                      //       child: Container(
                      //         padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 12),
                      //         width:boxSize.maxWidth*0.90,
                      // decoration: BoxDecoration(
                      //     color: Colors.grey[300],
                      // borderRadius: BorderRadius.circular(20)
                      // ),
                      //         child: Text('${_controllerPayment.cAddress.text}'.tr,style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      //             color: Colors.black,fontSize: 12,fontWeight: FontWeight.normal
                      //         ),
                      //         maxLines: 1,overflow: TextOverflow.ellipsis,
                      //         ),
                      
                      
                      //       )
                      //     ),
                      //      SizedBox(height: boxSize.maxHeight*0.04,),
                       
                      
                                    // invoiceRow(title: _controller.cartModel!.totals![0].title!,price: _controller.cartModel!.totals![0].text!),
                                    // SizedBox(height: boxSize.maxHeight*0.01,),
                                    // invoiceRow(title: _controller.cartModel!.totals![1].title!,price:  _controller.cartModel!.totals![1].text! ),
                                    // SizedBox(height: boxSize.maxHeight*0.01,),
                                    // invoiceRow(title: _controller.cartModel!.totals![2].title!,price:_controller.cartModel!.totals![2].text!),
                                    // SizedBox(height: boxSize.maxHeight*0.01,),
                                    // invoiceRow(title: _controller.cartModel!.totals![3].title!,price:_controller.cartModel!.totals![3].text!),
                                    // SizedBox(height: boxSize.maxHeight*0.01,),
                                   
                      
                               
                              
                    